/**
 * Post-build script: injects PWA meta tags, manifest link, service worker
 * registration, and mobile web-app optimizations into the Expo-built
 * dist/index.html.
 *
 * Run automatically via the "build:pwa" npm script after "build:web".
 */

const fs = require('fs');
const path = require('path');

const DIST_DIR = path.resolve(__dirname, '..', 'dist');
const HTML_PATH = path.join(DIST_DIR, 'index.html');
const PUBLIC_DIR = path.resolve(__dirname, '..', 'public');

const PWA_META = `
    <!-- PWA: Web App Manifest -->
    <link rel="manifest" href="/manifest.json" />
    <!-- PWA: Theme & background colors -->
    <meta name="theme-color" content="#4A90D9" />
    <meta name="background-color" content="#7EC8E3" />
    <!-- PWA: Fullscreen on mobile (iOS Safari + Android Chrome) -->
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="Paper Fly" />
    <!-- PWA: Portrait orientation lock -->
    <meta name="screen-orientation" content="portrait" />
    <!-- PWA: Apple touch icon -->
    <link rel="apple-touch-icon" href="/icon-192.png" />
    <!-- PWA: Prevent text size adjust & enable full touch -->
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-touch-fullscreen" content="yes" />
    <!-- PWA: Service worker registration -->
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
          navigator.serviceWorker.register('/sw.js').then(function (reg) {
            console.log('[PWA] Service Worker registered:', reg.scope);
          }).catch(function (err) {
            console.warn('[PWA] Service Worker registration failed:', err);
          });
        });
      }
    </script>`;

function copyPublic() {
  if (!fs.existsSync(PUBLIC_DIR)) return;
  const files = fs.readdirSync(PUBLIC_DIR);
  for (const file of files) {
    const src = path.join(PUBLIC_DIR, file);
    const dest = path.join(DIST_DIR, file);
    if (fs.statSync(src).isFile()) {
      fs.copyFileSync(src, dest);
      console.log(`[PWA] Copied ${file} -> dist/`);
    }
  }
}

function injectMeta() {
  if (!fs.existsSync(HTML_PATH)) {
    console.error('[PWA] dist/index.html not found. Run "build:web" first.');
    process.exit(1);
  }

  let html = fs.readFileSync(HTML_PATH, 'utf8');

  // Fix the <title>
  html = html.replace(
    /<title>[^<]*<\/title>/,
    '<title>Paper Fly</title>',
  );

  // Update viewport for full mobile app feel
  html = html.replace(
    /<meta name="viewport"[^>]*\/?>/,
    '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" />',
  );

  // Inject PWA meta tags right before </head>
  if (!html.includes('manifest.json')) {
    html = html.replace('</head>', `${PWA_META}\n  </head>`);
  }

  fs.writeFileSync(HTML_PATH, html);
  console.log('[PWA] Injected PWA meta tags into dist/index.html');
}

function main() {
  copyPublic();
  injectMeta();
  console.log('[PWA] Build complete. dist/ is now a PWA.');
}

main();
