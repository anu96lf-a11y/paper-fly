import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  TextInput,
  Modal,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Avatar } from '@/components/Avatar';
import { BannerAd } from '@/components/BannerAd';
import { sound } from '@/lib/sound';
import { loadLocalProfile, ensureProfile, randomAvatarSeed, saveLocalProfile } from '@/lib/player';

interface SettingsScreenProps {
  onBack: () => void;
}

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  const [profile, setProfile] = useState(() => loadLocalProfile());
  const [nameModal, setNameModal] = useState(false);
  const [tempName, setTempName] = useState(profile?.username ?? '');
  const [soundOn, setSoundOn] = useState(sound.isEnabled());

  const handleBack = () => {
    sound.play('click');
    onBack();
  };

  const handleSaveName = async () => {
    const name = tempName.trim();
    if (!name) {
      Alert.alert('Please enter a name');
      return;
    }
    const updated = await ensureProfile(name);
    setProfile(updated);
    setNameModal(false);
    sound.play('click');
  };

  const handleRandomAvatar = async () => {
    if (!profile) return;
    const updated = { ...profile, avatar_seed: randomAvatarSeed() };
    saveLocalProfile(updated);
    await ensureProfile(updated.username);
    setProfile(updated);
    sound.play('click');
  };

  const toggleSound = () => {
    const next = !soundOn;
    sound.setEnabled(next);
    setSoundOn(next);
    if (next) sound.play('click');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={handleBack}>
          <Text style={styles.backText}>‹ Back</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Settings</Text>
        <View style={styles.backBtn} />
      </View>

      <View style={styles.content}>
        {/* Profile section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PROFILE</Text>
          <View style={styles.profileCard}>
            {profile && <Avatar seed={profile.avatar_seed} size={56} />}
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{profile?.username ?? 'Pilot'}</Text>
              <Text style={styles.profileBest}>Best: {profile?.best_score ?? 0}</Text>
            </View>
          </View>
          <Pressable style={styles.actionBtn} onPress={() => { setTempName(profile?.username ?? ''); setNameModal(true); sound.play('click'); }}>
            <Text style={styles.actionBtnText}>✎ Edit Name</Text>
          </Pressable>
          <Pressable style={styles.actionBtn} onPress={handleRandomAvatar}>
            <Text style={styles.actionBtnText}>🎲 Change Avatar</Text>
          </Pressable>
        </View>

        {/* Sound section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>AUDIO</Text>
          <Pressable style={styles.toggleRow} onPress={toggleSound}>
            <Text style={styles.toggleLabel}>Sound & BGM</Text>
            <View style={[styles.toggle, soundOn ? styles.toggleOn : styles.toggleOff]}>
              <View style={[styles.toggleKnob, soundOn ? styles.knobOn : styles.knobOff]} />
            </View>
          </Pressable>
        </View>

        {/* About section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ABOUT</Text>
          <Text style={styles.aboutText}>Paper Fly v1.0</Text>
          <Text style={styles.aboutSub}>Tap to fly. Dodge obstacles. Chase the horizon across 4 dynamic stages.</Text>
        </View>
      </View>

      <BannerAd />

      {/* Name edit modal */}
      <Modal visible={nameModal} transparent animationType="fade" onRequestClose={() => setNameModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Your Pilot Name</Text>
            <TextInput
              style={styles.input}
              value={tempName}
              onChangeText={setTempName}
              maxLength={16}
              placeholder="Enter name..."
              placeholderTextColor="#aaa"
              autoCapitalize="words"
            />
            <View style={styles.modalBtnRow}>
              <Pressable style={styles.modalCancel} onPress={() => setNameModal(false)}>
                <Text style={styles.modalCancelText}>Cancel</Text>
              </Pressable>
              <Pressable style={styles.modalSave} onPress={handleSaveName}>
                <Text style={styles.modalSaveText}>Save</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a4e',
  },
  backBtn: {
    width: 70,
    paddingVertical: 8,
  },
  backText: {
    color: '#4A90D9',
    fontSize: 17,
    fontWeight: '700',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '900',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 28,
  },
  sectionTitle: {
    color: '#8a8aae',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginBottom: 12,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: '#2a2a4e',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 16,
    marginBottom: 10,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '800',
  },
  profileBest: {
    color: '#FFE08A',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 2,
  },
  actionBtn: {
    backgroundColor: '#2a2a4e',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 8,
  },
  actionBtnText: {
    color: '#4A90D9',
    fontSize: 15,
    fontWeight: '700',
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#2a2a4e',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderRadius: 14,
  },
  toggleLabel: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  toggle: {
    width: 52,
    height: 30,
    borderRadius: 15,
    padding: 3,
    justifyContent: 'center',
  },
  toggleOn: {
    backgroundColor: '#4A90D9',
  },
  toggleOff: {
    backgroundColor: '#3a3a5e',
  },
  toggleKnob: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#fff',
  },
  knobOn: {
    alignSelf: 'flex-end',
  },
  knobOff: {
    alignSelf: 'flex-start',
  },
  aboutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 6,
  },
  aboutSub: {
    color: '#8a8aae',
    fontSize: 14,
    lineHeight: 20,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCard: {
    width: 300,
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#1a1a2e',
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#1a1a2e',
    marginBottom: 20,
  },
  modalBtnRow: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancel: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalCancelText: {
    color: '#999',
    fontSize: 16,
    fontWeight: '700',
  },
  modalSave: {
    flex: 1,
    backgroundColor: '#4A90D9',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalSaveText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
  },
});
