import React, { useMemo } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import Svg, { Circle, Path, Rect, Ellipse, Defs, LinearGradient, Stop } from 'react-native-svg';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming, Easing, interpolate } from 'react-native-reanimated';
import { STAGE_THEMES } from '@/lib/gameConfig';
import type { StageId } from '@/lib/types';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');

interface ParallaxBackgroundProps {
  stage: StageId;
  scrollSpeed: number;
}

/** Animated drifting cloud/particle layer */
function FloatingParticles({ stage }: { stage: StageId }) {
  const theme = STAGE_THEMES[stage];
  const offset = useSharedValue(0);

  React.useEffect(() => {
    offset.value = withRepeat(
      withTiming(1, { duration: 8000, easing: Easing.inOut(Easing.sin) }),
      -1,
      true,
    );
  }, [offset]);

  const particles = useMemo(
    () =>
      Array.from({ length: 6 }, (_, i) => ({
        id: i,
        x: (i * 67 + 30) % SCREEN_W,
        y: 60 + ((i * 113) % 380),
        size: 16 + ((i * 7) % 22),
        delay: i * 0.4,
      })),
    [],
  );

  return (
    <>
      {particles.map((p) => {
        const style = useAnimatedStyle(() => ({
          transform: [
            { translateX: interpolate(offset.value, [0, 1], [0, 40]) },
            { translateY: interpolate(offset.value, [0, 1], [0, -16]) },
          ],
          opacity: interpolate(offset.value, [0, 0.5, 1], [0.4, 0.7, 0.4]),
        }));
        return (
          <Animated.View key={p.id} style={[styles.particleWrap, { left: p.x, top: p.y }, style]}>
            <Ellipse cx={p.size} cy={p.size * 0.5} rx={p.size} ry={p.size * 0.4} fill={theme.particle} opacity={0.6} />
          </Animated.View>
        );
      })}
    </>
  );
}

/** Stage-specific decorative elements (trees, buildings, pipes, stars) */
function StageDecor({ stage }: { stage: StageId }) {
  const theme = STAGE_THEMES[stage];
  const groundY = SCREEN_H - 80;

  switch (stage) {
    case 1:
      return (
        <Svg style={StyleSheet.absoluteFill} width={SCREEN_W} height={SCREEN_H}>
          {[0, 1, 2, 3, 4].map((i) => {
            const x = i * 95 + 20;
            const h = 50 + ((i * 37) % 40);
            return (
              <React.Fragment key={i}>
                <Path d={`M${x},${groundY} L${x},${groundY - h} L${x + 30},${groundY - h - 20} L${x + 60},${groundY - h} L${x + 60},${groundY} Z`} fill={theme.obstacleColor} opacity={0.5} />
                <Rect x={x + 25} y={groundY - h - 24} width={10} height={24} fill={theme.obstacleAccent} opacity={0.6} />
              </React.Fragment>
            );
          })}
        </Svg>
      );
    case 2:
      return (
        <Svg style={StyleSheet.absoluteFill} width={SCREEN_W} height={SCREEN_H}>
          {[0, 1, 2, 3, 4, 5].map((i) => {
            const x = i * 72 + 10;
            const h = 120 + ((i * 53) % 80);
            return (
              <React.Fragment key={i}>
                <Rect x={x} y={groundY - h} width={50} height={h} fill={theme.obstacleColor} opacity={0.45} />
                <Rect x={x + 5} y={groundY - h + 10} width={8} height={8} fill={theme.accent} opacity={0.5} />
                <Rect x={x + 20} y={groundY - h + 10} width={8} height={8} fill={theme.accent} opacity={0.5} />
                <Rect x={x + 35} y={groundY - h + 10} width={8} height={8} fill={theme.accent} opacity={0.5} />
                <Rect x={x + 5} y={groundY - h + 30} width={8} height={8} fill={theme.accent} opacity={0.4} />
                <Rect x={x + 20} y={groundY - h + 30} width={8} height={8} fill={theme.accent} opacity={0.4} />
                <Rect x={x + 35} y={groundY - h + 30} width={8} height={8} fill={theme.accent} opacity={0.4} />
              </React.Fragment>
            );
          })}
        </Svg>
      );
    case 3:
      return (
        <Svg style={StyleSheet.absoluteFill} width={SCREEN_W} height={SCREEN_H}>
          {[0, 1, 2, 3, 4, 5].map((i) => {
            const x = i * 70 + 15;
            const h = 90 + ((i * 41) % 50);
            return (
              <React.Fragment key={i}>
                <Rect x={x} y={groundY - h} width={40} height={h} fill={theme.obstacleColor} opacity={0.5} rx={4} />
                <Circle cx={x + 20} cy={groundY - h - 5} r={14} fill={theme.obstacleAccent} opacity={0.5} />
                <Rect x={x + 16} y={groundY - h + 15} width={8} height={h - 30} fill={theme.obstacleAccent} opacity={0.4} />
              </React.Fragment>
            );
          })}
        </Svg>
      );
    case 4:
      return (
        <Svg style={StyleSheet.absoluteFill} width={SCREEN_W} height={SCREEN_H}>
          {Array.from({ length: 20 }, (_, i) => {
            const x = (i * 87 + 13) % SCREEN_W;
            const y = (i * 53 + 7) % (SCREEN_H - 120);
            const r = 1 + ((i * 3) % 3);
            return <Circle key={i} cx={x} cy={y} r={r} fill="#FFFFFF" opacity={0.7} />;
          })}
          <Ellipse cx={SCREEN_W * 0.8} cy={120} rx={60} ry={28} fill="#3A2A5E" opacity={0.6} />
          <Ellipse cx={SCREEN_W * 0.2} cy={90} rx={50} ry={22} fill="#3A2A5E" opacity={0.5} />
          <Circle cx={SCREEN_W * 0.5} cy={100} r={24} fill="#FFE66D" opacity={0.3} />
        </Svg>
      );
  }
}

export function ParallaxBackground({ stage }: ParallaxBackgroundProps) {
  const theme = STAGE_THEMES[stage];

  return (
    <View style={StyleSheet.absoluteFill}>
      {/* Sky gradient */}
      <View style={[StyleSheet.absoluteFill, { backgroundColor: theme.skyTop }]} />
      <Svg style={StyleSheet.absoluteFill} width={SCREEN_W} height={SCREEN_H}>
        <Defs>
          <LinearGradient id={`sky-${stage}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor={theme.skyTop} />
            <Stop offset="1" stopColor={theme.skyBottom} />
          </LinearGradient>
        </Defs>
        <Rect width={SCREEN_W} height={SCREEN_H} fill={`url(#sky-${stage})`} />
      </Svg>

      {/* Decorative elements */}
      <StageDecor stage={stage} />

      {/* Floating particles (clouds/stars) */}
      <FloatingParticles stage={stage} />

      {/* Ground */}
      <View style={[styles.ground, { backgroundColor: theme.groundColor }]} />
      <View style={[styles.groundAccent, { backgroundColor: theme.obstacleColor }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  ground: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 70,
  },
  groundAccent: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 70,
    height: 6,
    opacity: 0.5,
  },
  particleWrap: {
    position: 'absolute',
  },
});
