import React, { useEffect } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import Svg, { Circle, Path, Ellipse, Rect, Defs, LinearGradient, RadialGradient, Stop } from 'react-native-svg';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSequence,
  withDelay,
  Easing,
  interpolate,
  runOnJS,
} from 'react-native-reanimated';
import { PaperPlane } from './PaperPlane';

const { width: W, height: H } = Dimensions.get('window');

interface IntroAnimationProps {
  onComplete: () => void;
}

/**
 * Subway-Surfers-style intro: a boy throws a paper plane upward,
 * the camera zooms toward the plane, then transitions into gameplay.
 */
export function IntroAnimation({ onComplete }: IntroAnimationProps) {
  const boyScale = useSharedValue(1);
  const boyY = useSharedValue(0);
  const armRot = useSharedValue(0);
  const planeY = useSharedValue(H * 0.55);
  const planeX = useSharedValue(W * 0.5);
  const planeScale = useSharedValue(1);
  const planeRotation = useSharedValue(-20);
  const sceneScale = useSharedValue(1);
  const sceneOpacity = useSharedValue(1);

  useEffect(() => {
    // Phase 1 (0-1s): boy winds up and throws with arm swing
    boyY.value = withSequence(
      withTiming(-10, { duration: 350, easing: Easing.out(Easing.quad) }),
      withTiming(24, { duration: 250, easing: Easing.in(Easing.quad) }),
      withTiming(16, { duration: 400, easing: Easing.out(Easing.quad) }),
    );
    boyScale.value = withSequence(
      withTiming(1.06, { duration: 350 }),
      withTiming(0.94, { duration: 250 }),
      withTiming(0.98, { duration: 400 }),
    );
    armRot.value = withSequence(
      withTiming(-50, { duration: 350, easing: Easing.inOut(Easing.quad) }),
      withTiming(75, { duration: 200, easing: Easing.out(Easing.quad) }),
      withTiming(55, { duration: 450, easing: Easing.inOut(Easing.quad) }),
    );

    // Phase 2 (0.4-1.6s): plane launches upward and to the right
    planeY.value = withDelay(
      400,
      withTiming(H * 0.28, { duration: 1000, easing: Easing.out(Easing.quad) }),
    );
    planeX.value = withDelay(
      400,
      withTiming(W * 0.26, { duration: 1000, easing: Easing.inOut(Easing.quad) }),
    );
    planeRotation.value = withDelay(
      400,
      withSequence(
        withTiming(-32, { duration: 450, easing: Easing.out(Easing.quad) }),
        withTiming(8, { duration: 550, easing: Easing.inOut(Easing.quad) }),
      ),
    );

    // Phase 3 (1.6-2.8s): camera zooms into the plane
    sceneScale.value = withDelay(
      1600,
      withTiming(3.8, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
    );
    planeScale.value = withDelay(
      1600,
      withTiming(1.7, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
    );

    // Phase 4 (2.6-3s): fade to gameplay
    sceneOpacity.value = withDelay(
      2600,
      withTiming(0, { duration: 400, easing: Easing.inOut(Easing.quad) }, (finished) => {
        if (finished) runOnJS(onComplete)();
      }),
    );
  }, []);

  const sceneStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: sceneScale.value },
      { translateX: -W * 0.5 * (sceneScale.value - 1) },
      { translateY: -H * 0.5 * (sceneScale.value - 1) },
    ],
    opacity: sceneOpacity.value,
  }));

  const boyStyle = useAnimatedStyle(() => ({
    transform: [{ scale: boyScale.value }, { translateY: boyY.value }],
  }));

  const armStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${armRot.value}deg` }],
  }));

  const planeStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: planeX.value },
      { translateY: planeY.value },
      { scale: planeScale.value },
    ],
  }));

  return (
    <View style={styles.container}>
      <Animated.View style={[StyleSheet.absoluteFill, sceneStyle]}>
        {/* Sky gradient */}
        <View style={[StyleSheet.absoluteFill, { backgroundColor: '#7EC8E3' }]} />
        <Svg style={StyleSheet.absoluteFill} width={W} height={H}>
          <Defs>
            <LinearGradient id="introSky" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#7EC8E3" />
              <Stop offset="0.6" stopColor="#A8D8EA" />
              <Stop offset="1" stopColor="#D4F1D4" />
            </LinearGradient>
            <RadialGradient id="sunGlow" cx="0.5" cy="0.5" r="0.5">
              <Stop offset="0" stopColor="#FFE08A" stopOpacity="0.6" />
              <Stop offset="1" stopColor="#FFE08A" stopOpacity="0" />
            </RadialGradient>
            <LinearGradient id="hillFar" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#9BCF5A" />
              <Stop offset="1" stopColor="#7BAE3F" />
            </LinearGradient>
            <LinearGradient id="hillNear" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#6BA02E" />
              <Stop offset="1" stopColor="#4E8B22" />
            </LinearGradient>
          </Defs>
          <Rect width={W} height={H} fill="url(#introSky)" />
          {/* Sun with glow */}
          <Circle cx={W * 0.75} cy={H * 0.18} r={80} fill="url(#sunGlow)" />
          <Circle cx={W * 0.75} cy={H * 0.18} r={36} fill="#FFE08A" opacity={0.9} />
          {/* Distant hills with gradient */}
          <Path d={`M0,${H * 0.68} Q${W * 0.3},${H * 0.52} ${W * 0.6},${H * 0.63} T${W},${H * 0.58} L${W},${H} L0,${H} Z`} fill="url(#hillFar)" opacity={0.65} />
          <Path d={`M0,${H * 0.78} Q${W * 0.25},${H * 0.66} ${W * 0.5},${H * 0.74} T${W},${H * 0.71} L${W},${H} L0,${H} Z`} fill="url(#hillNear)" opacity={0.8} />
          {/* Decorative clouds */}
          <Ellipse cx={W * 0.15} cy={H * 0.2} rx={45} ry={18} fill="#fff" opacity={0.7} />
          <Ellipse cx={W * 0.4} cy={H * 0.15} rx={38} ry={15} fill="#fff" opacity={0.5} />
        </Svg>

        {/* Boy character */}
        <Animated.View style={[styles.boy, boyStyle]}>
          <Boy />
          {/* Animated throwing arm */}
          <Animated.View style={[styles.throwArm, armStyle]}>
            <ThrowArm />
          </Animated.View>
        </Animated.View>

        {/* Paper plane */}
        <Animated.View style={[styles.plane, planeStyle]}>
          <PaperPlane size={54} rotation={planeRotation.value} color="#FFFFFF" accent="#A8B8CC" />
        </Animated.View>
      </Animated.View>
    </View>
  );
}

/**
 * Detailed semi-realistic boy character with gradient skin, layered hair,
 * expressive eyes with pupils and highlights, eyebrows, nose, charming smile,
 * rosy cheeks, and clothing with folds and shading.
 */
function Boy() {
  return (
    <Svg width={160} height={200} viewBox="0 0 160 200">
      <Defs>
        <LinearGradient id="skin" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#FFDFC0" />
          <Stop offset="1" stopColor="#F0BC95" />
        </LinearGradient>
        <LinearGradient id="skinShade" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#F5C8A0" />
          <Stop offset="1" stopColor="#E0A878" />
        </LinearGradient>
        <LinearGradient id="hair" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#6B4226" />
          <Stop offset="1" stopColor="#4A2D16" />
        </LinearGradient>
        <LinearGradient id="hairShine" x1="0" y1="0" x2="1" y2="0">
          <Stop offset="0" stopColor="#8B5A3C" />
          <Stop offset="0.5" stopColor="#A06840" />
          <Stop offset="1" stopColor="#6B4226" />
        </LinearGradient>
        <LinearGradient id="shirt" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#5BA0E8" />
          <Stop offset="1" stopColor="#3878C0" />
        </LinearGradient>
        <LinearGradient id="pants" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#3A5A8C" />
          <Stop offset="1" stopColor="#2A4566" />
        </LinearGradient>
        <RadialGradient id="cheek" cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#FFA0A0" stopOpacity="0.5" />
          <Stop offset="1" stopColor="#FFA0A0" stopOpacity="0" />
        </RadialGradient>
      </Defs>

      {/* Neck */}
      <Path d="M68,82 L92,82 L90,100 L70,100 Z" fill="url(#skinShade)" />

      {/* Body / shirt with collar and folds */}
      <Path d="M42,100 Q60,92 80,90 Q100,92 118,100 L122,150 Q100,158 80,156 Q60,158 38,150 Z" fill="url(#shirt)" />
      {/* Shirt collar */}
      <Path d="M68,90 Q80,96 92,90 L90,100 Q80,104 70,100 Z" fill="#4885D0" opacity={0.8} />
      {/* Shirt fold shading */}
      <Path d="M55,110 Q58,130 55,148" stroke="#3878C0" strokeWidth="2" fill="none" opacity={0.4} />
      <Path d="M100,110 Q103,130 100,148" stroke="#3878C0" strokeWidth="2" fill="none" opacity={0.4} />

      {/* Left arm (relaxed) */}
      <Path d="M42,102 Q26,118 22,138" stroke="url(#skin)" strokeWidth="14" strokeLinecap="round" fill="none" />
      <Circle cx={22} cy={140} r="8" fill="url(#skin)" />

      {/* Legs / pants with creases */}
      <Path d="M58,150 L56,188 L70,188 L72,150 Z" fill="url(#pants)" />
      <Path d="M88,150 L90,188 L104,188 L102,150 Z" fill="url(#pants)" />
      <Path d="M62,160 L62,178" stroke="#2A4566" strokeWidth="1.5" opacity={0.5} />
      <Path d="M96,160 L96,178" stroke="#2A4566" strokeWidth="1.5" opacity={0.5} />

      {/* Shoes */}
      <Ellipse cx={63} cy={192} rx={14} ry={6} fill="#2A2A3A" />
      <Ellipse cx={97} cy={192} rx={14} ry={6} fill="#2A2A3A" />
      <Path d="M52,188 L74,188 L72,192 L54,192 Z" fill="#3A3A4A" />
      <Path d="M86,188 L108,188 L106,192 L88,192 Z" fill="#3A3A4A" />

      {/* Head — slightly oval for realism */}
      <Ellipse cx={80} cy={56} rx={32} ry={35} fill="url(#skin)" />

      {/* Ears */}
      <Ellipse cx={48} cy={58} rx={7} ry={11} fill="url(#skinShade)" />
      <Ellipse cx={112} cy={58} rx={7} ry={11} fill="url(#skinShade)" />
      <Path d="M46,54 Q44,60 48,62" stroke="#D89868" strokeWidth="1.5" fill="none" />
      <Path d="M114,54 Q116,60 112,62" stroke="#D89868" strokeWidth="1.5" fill="none" />

      {/* Hair — layered with volume and shine */}
      <Path d="M46,48 Q44,24 68,18 Q82,14 96,18 Q118,22 114,50 Q108,34 96,30 Q88,36 80,32 Q72,36 64,30 Q52,34 46,48 Z" fill="url(#hair)" />
      {/* Hair top volume */}
      <Path d="M56,28 Q64,16 82,14 Q100,16 108,28 Q98,22 82,22 Q66,22 56,28 Z" fill="url(#hairShine)" opacity={0.6} />
      {/* Hair strands detail */}
      <Path d="M60,30 Q66,20 72,26" stroke="#4A2D16" strokeWidth="1.5" fill="none" opacity={0.5} />
      <Path d="M84,24 Q92,18 100,26" stroke="#4A2D16" strokeWidth="1.5" fill="none" opacity={0.5} />
      <Path d="M70,40 Q74,34 80,36" stroke="#5C3A21" strokeWidth="1" fill="none" opacity={0.4} />

      {/* Eyebrows */}
      <Path d="M60,44 Q66,41 74,44" stroke="#5C3A21" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <Path d="M86,44 Q94,41 100,44" stroke="#5C3A21" strokeWidth="2.5" fill="none" strokeLinecap="round" />

      {/* Eyes — white sclera, colored iris, pupil, highlight */}
      <Ellipse cx={67} cy={54} rx="7" ry="8" fill="#FFFFFF" />
      <Ellipse cx={93} cy={54} rx="7" ry="8" fill="#FFFFFF" />
      {/* Iris */}
      <Circle cx={68} cy={55} r="5" fill="#5C8B6A" />
      <Circle cx={94} cy={55} r="5" fill="#5C8B6A" />
      {/* Pupil */}
      <Circle cx={68} cy={55} r="2.5" fill="#1a1a2e" />
      <Circle cx={94} cy={55} r="2.5" fill="#1a1a2e" />
      {/* Eye highlights */}
      <Circle cx={69.5} cy={53.5} r="1.5" fill="#FFFFFF" />
      <Circle cx={95.5} cy={53.5} r="1.5" fill="#FFFFFF" />
      {/* Eyelash / upper lid line */}
      <Path d="M60,50 Q67,48 74,50" stroke="#3A2A1A" strokeWidth="2" fill="none" strokeLinecap="round" />
      <Path d="M86,50 Q93,48 100,50" stroke="#3A2A1A" strokeWidth="2" fill="none" strokeLinecap="round" />

      {/* Nose */}
      <Path d="M80,58 Q78,64 76,68 Q78,70 82,68 Q84,66 82,60" fill="url(#skinShade)" opacity={0.5} />
      <Path d="M78,67 Q80,69 83,67" stroke="#D89868" strokeWidth="1" fill="none" strokeLinecap="round" />

      {/* Cheeks — rosy blush */}
      <Circle cx={58} cy={64} r="9" fill="url(#cheek)" />
      <Circle cx={102} cy={64} r="9" fill="url(#cheek)" />

      {/* Charming smile — curved with slight open expression */}
      <Path d="M70,74 Q80,82 90,74" stroke="#B85A3A" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <Path d="M72,75 Q80,80 88,75 Q84,78 80,78 Q76,78 72,75 Z" fill="#D4684A" opacity={0.3} />
      {/* Upper lip line */}
      <Path d="M69,73 Q75,71 80,72 Q85,71 91,73" stroke="#C05A3A" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity={0.6} />
    </Svg>
  );
}

/** Throwing arm — separate so it can rotate independently */
function ThrowArm() {
  return (
    <Svg width={70} height={70} viewBox="0 0 70 70">
      <Defs>
        <LinearGradient id="armSkin" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#FFDFC0" />
          <Stop offset="1" stopColor="#E8B888" />
        </LinearGradient>
        <LinearGradient id="armShirt" x1="0" y1="0" x2="1" y2="0">
          <Stop offset="0" stopColor="#5BA0E8" />
          <Stop offset="1" stopColor="#3878C0" />
        </LinearGradient>
      </Defs>
      {/* Upper arm with shirt sleeve */}
      <Path d="M5,10 Q12,5 25,8 L28,22 Q18,25 8,20 Z" fill="url(#armShirt)" />
      {/* Forearm skin */}
      <Path d="M22,16 Q40,22 58,30" stroke="url(#armSkin)" strokeWidth="12" strokeLinecap="round" fill="none" />
      {/* Hand */}
      <Circle cx={58} cy={30} r="8" fill="url(#armSkin)" />
      {/* Finger detail */}
      <Path d="M58,26 Q62,22 66,24" stroke="#D89868" strokeWidth="2" fill="none" strokeLinecap="round" />
      <Path d="M60,32 Q64,34 66,30" stroke="#D89868" strokeWidth="1.5" fill="none" strokeLinecap="round" />
    </Svg>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#7EC8E3',
  },
  boy: {
    position: 'absolute',
    left: W * 0.5 - 80,
    top: H * 0.5 - 40,
  },
  throwArm: {
    position: 'absolute',
    left: 98,
    top: 92,
  },
  plane: {
    position: 'absolute',
    left: -27,
    top: -27,
  },
});
