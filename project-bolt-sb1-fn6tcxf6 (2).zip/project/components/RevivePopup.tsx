import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Modal, ActivityIndicator } from 'react-native';
import { ads } from '@/lib/ads';
import { sound } from '@/lib/sound';

interface RevivePopupProps {
  onWatch: () => void;
  onDecline: () => void;
}

export function RevivePopup({ onWatch, onDecline }: RevivePopupProps) {
  const [watching, setWatching] = useState(false);

  const handleWatch = () => {
    sound.play('click');
    setWatching(true);
    let rewarded = false;
    ads.showRewarded((event) => {
      if (event === 'loaded') {
        // ad is showing
      }
      if (event === 'rewarded') {
        rewarded = true;
      }
      if (event === 'closed' || event === 'skipped' || event === 'failed') {
        setWatching(false);
        if (rewarded) {
          onWatch();
        }
      }
    });
  };

  const handleDecline = () => {
    sound.play('click');
    onDecline();
  };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={handleDecline}>
      <View style={styles.overlay}>
        <View style={styles.card}>
          {watching ? (
            <View style={styles.watchingContainer}>
              <ActivityIndicator size="large" color="#4A90D9" />
              <Text style={styles.watchingTitle}>Loading Ad...</Text>
              <Text style={styles.watchingSub}>Your reward will be granted shortly</Text>
            </View>
          ) : (
            <>
              <View style={styles.iconCircle}>
                <Text style={styles.icon}>✈</Text>
              </View>
              <Text style={styles.title}>Continue?</Text>
              <Text style={styles.subtitle}>
                Watch a short video ad to revive and keep flying from your current score!
              </Text>
              <Pressable style={styles.watchBtn} onPress={handleWatch}>
                <Text style={styles.watchText}>▶ Watch Ad & Revive</Text>
              </Pressable>
              <Pressable style={styles.declineBtn} onPress={handleDecline}>
                <Text style={styles.declineText}>No Thanks</Text>
              </Pressable>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    width: 320,
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 28,
    alignItems: 'center',
  },
  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#E8F0FE',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  icon: {
    fontSize: 36,
  },
  title: {
    fontSize: 26,
    fontWeight: '900',
    color: '#1a1a2e',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: '#555',
    textAlign: 'center',
    lineHeight: 21,
    marginBottom: 24,
  },
  watchBtn: {
    width: '100%',
    backgroundColor: '#4A90D9',
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 12,
  },
  watchText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '800',
  },
  declineBtn: {
    width: '100%',
    paddingVertical: 12,
    alignItems: 'center',
  },
  declineText: {
    color: '#999',
    fontSize: 15,
    fontWeight: '600',
  },
  watchingContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  watchingTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#1a1a2e',
    marginTop: 16,
  },
  watchingSub: {
    fontSize: 14,
    color: '#777',
    marginTop: 6,
  },
});
