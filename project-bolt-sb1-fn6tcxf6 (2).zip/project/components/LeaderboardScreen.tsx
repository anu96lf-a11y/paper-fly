import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Avatar } from '@/components/Avatar';
import { BannerAd } from '@/components/BannerAd';
import { fetchLeaderboard } from '@/lib/player';
import { sound } from '@/lib/sound';
import type { ScoreRow } from '@/lib/types';

interface LeaderboardScreenProps {
  onBack: () => void;
}

export function LeaderboardScreen({ onBack }: LeaderboardScreenProps) {
  const [top, setTop] = useState<ScoreRow[]>([]);
  const [myRank, setMyRank] = useState<number | null>(null);
  const [myScore, setMyScore] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const result = await fetchLeaderboard();
    setTop(result.top);
    setMyRank(result.myRank);
    setMyScore(result.myScore);
    if (result.top.length === 0 && !loading) {
      setError('No scores yet. Be the first to fly!');
    } else {
      setError(null);
    }
  }, [loading]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await load();
      setLoading(false);
    })();
  }, []);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }, [load]);

  const handleBack = () => {
    sound.play('click');
    onBack();
  };

  const renderItem = ({ item, index }: { item: ScoreRow; index: number }) => {
    const rank = index + 1;
    const isMe = item.device_id === (top.find((t) => t.device_id === item.device_id)?.device_id);
    const medalColors = ['#FFD700', '#C0C0C0', '#CD7F32'];
    const medal = rank <= 3 ? medalColors[rank - 1] : null;

    return (
      <View style={[styles.rankRow, isMe && styles.rankRowMe]}>
        <View style={[styles.rankNum, medal ? { backgroundColor: medal } : null]}>
          <Text style={[styles.rankNumText, medal ? { color: '#1a1a2e' } : null]}>{rank}</Text>
        </View>
        <Avatar seed={item.avatar_seed ?? 'plane'} size={40} />
        <View style={styles.rankInfo}>
          <Text style={styles.rankName} numberOfLines={1}>{item.username}</Text>
          <Text style={styles.rankStage}>Stage {item.stage_reached}</Text>
        </View>
        <Text style={styles.rankScore}>{item.score}</Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={handleBack}>
          <Text style={styles.backText}>‹ Back</Text>
        </Pressable>
        <Text style={styles.headerTitle}>🏆 Leaderboard</Text>
        <View style={styles.backBtn} />
      </View>

      {loading ? (
        <View style={styles.centerMsg}>
          <ActivityIndicator size="large" color="#4A90D9" />
          <Text style={styles.loadingText}>Loading rankings...</Text>
        </View>
      ) : error && top.length === 0 ? (
        <View style={styles.centerMsg}>
          <Text style={styles.emptyTitle}>No Scores Yet</Text>
          <Text style={styles.emptySub}>Play a round to claim the top spot!</Text>
        </View>
      ) : (
        <FlatList
          data={top}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={['#4A90D9']} />
          }
          ListHeaderComponent={
            <Text style={styles.listHeader}>Global Top 10</Text>
          }
          ListFooterComponent={
            myRank !== null && myRank > 10 ? (
              <View style={styles.footerRow}>
                <View style={[styles.rankRow, styles.rankRowMe]}>
                  <View style={styles.rankNum}>
                    <Text style={styles.rankNumText}>{myRank}</Text>
                  </View>
                  <Text style={styles.meLabel}>YOU</Text>
                  <Text style={styles.rankScore}>{myScore}</Text>
                </View>
              </View>
            ) : null
          }
        />
      )}

      <BannerAd />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a4e',
  },
  backBtn: {
    width: 70,
    paddingVertical: 8,
  },
  backText: {
    color: '#4A90D9',
    fontSize: 17,
    fontWeight: '700',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '900',
  },
  list: {
    padding: 16,
    paddingBottom: 80,
  },
  listHeader: {
    color: '#8a8aae',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginBottom: 12,
    marginLeft: 4,
  },
  rankRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2a2a4e',
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    marginBottom: 8,
    gap: 12,
  },
  rankRowMe: {
    backgroundColor: '#4A90D9',
  },
  rankNum: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#3a3a5e',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankNumText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '800',
  },
  rankInfo: {
    flex: 1,
  },
  rankName: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '700',
  },
  rankStage: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    marginTop: 2,
  },
  rankScore: {
    color: '#FFE08A',
    fontSize: 22,
    fontWeight: '900',
  },
  centerMsg: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    color: '#8a8aae',
    marginTop: 12,
    fontSize: 15,
  },
  emptyTitle: {
    color: '#fff',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 8,
  },
  emptySub: {
    color: '#8a8aae',
    fontSize: 15,
  },
  meLabel: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '800',
    flex: 1,
  },
  footerRow: {
    marginTop: 16,
  },
});
