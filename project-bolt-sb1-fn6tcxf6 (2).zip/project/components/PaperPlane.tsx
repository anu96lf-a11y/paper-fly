import React from 'react';
import { StyleSheet } from 'react-native';
import Svg, { Path, Polygon, Defs, LinearGradient, Stop } from 'react-native-svg';

interface PaperPlaneProps {
  size?: number;
  color?: string;
  accent?: string;
  rotation?: number;
}

/**
 * Detailed origami paper plane with layered folds, gradient shading,
 * and cast shadow. Facing right (flight direction).
 */
export function PaperPlane({ size = 48, color = '#FFFFFF', accent = '#A8B8CC', rotation = 0 }: PaperPlaneProps) {
  return (
    <Svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      style={[{ transform: [{ rotate: `${rotation}deg` }] }, styles.shadow]}
    >
      <Defs>
        <LinearGradient id="planeTop" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={color} />
          <Stop offset="1" stopColor="#E8EDF2" />
        </LinearGradient>
        <LinearGradient id="planeMid" x1="0" y1="0" x2="1" y2="0.5">
          <Stop offset="0" stopColor={color} />
          <Stop offset="1" stopColor="#D8E0E8" />
        </LinearGradient>
        <LinearGradient id="planeShade" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={accent} stopOpacity="0.5" />
          <Stop offset="1" stopColor={accent} stopOpacity="0.75" />
        </LinearGradient>
      </Defs>

      {/* Top wing — main upward fold */}
      <Polygon
        points="6,50 96,12 62,50"
        fill="url(#planeTop)"
        stroke={accent}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      {/* Top wing inner fold line */}
      <Path d="M6,50 L62,50" stroke={accent} strokeWidth="0.6" opacity={0.5} />
      <Path d="M20,46 L62,50 L48,30" stroke={accent} strokeWidth="0.4" fill="none" opacity={0.3} />

      {/* Center body section */}
      <Polygon
        points="6,50 96,12 96,12 62,50 58,86 38,60"
        fill="url(#planeMid)"
        opacity={0.95}
      />

      {/* Bottom wing — angled downward fold */}
      <Polygon
        points="6,50 62,50 58,86"
        fill="url(#planeShade)"
      />
      {/* Bottom wing fold crease */}
      <Path
        d="M6,50 L62,50 L58,86"
        fill="none"
        stroke={accent}
        strokeWidth="1"
        strokeLinejoin="round"
      />

      {/* Underside shadow — the dark belly of the fold */}
      <Polygon
        points="62,50 96,12 58,86"
        fill={accent}
        opacity={0.3}
      />

      {/* Tail flap — small triangular fold at back */}
      <Polygon
        points="38,60 58,86 46,58"
        fill={accent}
        opacity={0.45}
      />
      <Path d="M38,60 L46,58" stroke={accent} strokeWidth="0.5" opacity={0.6} />

      {/* Nose tip highlight */}
      <Path d="M92,14 L96,12 L93,18" fill="#FFFFFF" opacity={0.6} />

      {/* Fine fold crease lines for origami detail */}
      <Path d="M30,48 L62,50" stroke={accent} strokeWidth="0.3" opacity={0.25} />
      <Path d="M45,52 L62,50" stroke={accent} strokeWidth="0.3" opacity={0.2} />
      <Path d="M50,55 L58,80" stroke={accent} strokeWidth="0.3" opacity={0.2} />

      {/* Wing edge subtle line */}
      <Path d="M6,50 L96,12" stroke="#FFFFFF" strokeWidth="0.5" opacity={0.4} />
    </Svg>
  );
}

const styles = StyleSheet.create({
  shadow: {
    shadowColor: '#000',
    shadowOffset: { width: 1, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 6,
    elevation: 5,
  },
});
