import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Path, Ellipse, Defs, LinearGradient, Stop, Rect } from 'react-native-svg';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { PaperPlane } from '@/components/PaperPlane';
import { BannerAd } from '@/components/BannerAd';
import { sound } from '@/lib/sound';
import { loadLocalProfile } from '@/lib/player';

const { width: W, height: H } = Dimensions.get('window');

interface MainMenuProps {
  onPlay: () => void;
  onLeaderboard: () => void;
  onSettings: () => void;
}

export function MainMenu({ onPlay, onLeaderboard, onSettings }: MainMenuProps) {
  const [soundOn, setSoundOn] = useState(sound.isEnabled());
  const profile = loadLocalProfile();

  const planeFloat = useSharedValue(0);
  useEffect(() => {
    planeFloat.value = withRepeat(
      withSequence(
        withTiming(-12, { duration: 1800, easing: Easing.inOut(Easing.sin) }),
        withTiming(12, { duration: 1800, easing: Easing.inOut(Easing.sin) }),
      ),
      -1,
      true,
    );
  }, []);

  const planeStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: planeFloat.value }, { rotate: '-8deg' }],
  }));

  const toggleSound = () => {
    const next = !soundOn;
    sound.setEnabled(next);
    setSoundOn(next);
    if (next) sound.play('click');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Sky background */}
      <View style={StyleSheet.absoluteFill}>
        <View style={[StyleSheet.absoluteFill, { backgroundColor: '#7EC8E3' }]} />
        <Svg style={StyleSheet.absoluteFill} width={W} height={H}>
          <Defs>
            <LinearGradient id="menuSky" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#7EC8E3" />
              <Stop offset="0.6" stopColor="#A8D8EA" />
              <Stop offset="1" stopColor="#D4F1D4" />
            </LinearGradient>
          </Defs>
          <Rect width={W} height={H} fill="url(#menuSky)" />
          {/* Sun */}
          <Circle cx={W * 0.8} cy={H * 0.15} r={45} fill="#FFE08A" opacity={0.8} />
          <Circle cx={W * 0.8} cy={H * 0.15} r={60} fill="#FFE08A" opacity={0.2} />
          {/* Clouds */}
          <Ellipse cx={W * 0.15} cy={H * 0.18} rx={50} ry={20} fill="#fff" opacity={0.7} />
          <Ellipse cx={W * 0.35} cy={H * 0.22} rx={40} ry={16} fill="#fff" opacity={0.5} />
          <Ellipse cx={W * 0.6} cy={H * 0.12} rx={45} ry={18} fill="#fff" opacity={0.6} />
          {/* Hills */}
          <Path d={`M0,${H * 0.75} Q${W * 0.3},${H * 0.6} ${W * 0.6},${H * 0.7} T${W},${H * 0.65} L${W},${H} L0,${H} Z`} fill="#7BAE3F" opacity={0.5} />
          <Path d={`M0,${H * 0.85} Q${W * 0.25},${H * 0.75} ${W * 0.5},${H * 0.82} T${W},${H * 0.78} L${W},${H} L0,${H} Z`} fill="#5E8B2D" opacity={0.7} />
        </Svg>
      </View>

      {/* Floating paper plane */}
      <Animated.View style={[styles.floatingPlane, planeStyle]}>
        <PaperPlane size={64} rotation={-8} color="#FFFFFF" accent="#B0C4DE" />
      </Animated.View>

      {/* Content */}
      <View style={styles.content}>
        <Text style={styles.title}>PAPER FLY</Text>
        <Text style={styles.tagline}>Endless Sky Adventure</Text>

        <Pressable style={styles.playBtn} onPress={() => { sound.play('click'); onPlay(); }}>
          <Text style={styles.playText}>▶ PLAY</Text>
        </Pressable>

        <View style={styles.buttonRow}>
          <Pressable style={styles.iconBtn} onPress={() => { sound.play('click'); onLeaderboard(); }}>
            <Text style={styles.iconBtnEmoji}>🏆</Text>
            <Text style={styles.iconBtnLabel}>Ranks</Text>
          </Pressable>

          <Pressable style={styles.iconBtn} onPress={() => { sound.play('click'); onSettings(); }}>
            <Text style={styles.iconBtnEmoji}>⚙</Text>
            <Text style={styles.iconBtnLabel}>Settings</Text>
          </Pressable>

          <Pressable style={styles.iconBtn} onPress={toggleSound}>
            <Text style={styles.iconBtnEmoji}>{soundOn ? '🔊' : '🔇'}</Text>
            <Text style={styles.iconBtnLabel}>{soundOn ? 'ON' : 'OFF'}</Text>
          </Pressable>
        </View>

        {profile && profile.best_score > 0 && (
          <View style={styles.bestBox}>
            <Text style={styles.bestLabel}>YOUR BEST</Text>
            <Text style={styles.bestScore}>{profile.best_score}</Text>
          </View>
        )}
      </View>

      {/* Banner ad */}
      <BannerAd />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingTop: 20,
  },
  title: {
    fontSize: 56,
    fontWeight: '900',
    color: '#FFFFFF',
    letterSpacing: 2,
    textShadowColor: 'rgba(0,0,0,0.25)',
    textShadowOffset: { width: 0, height: 4 },
    textShadowRadius: 8,
    marginBottom: 4,
  },
  tagline: {
    fontSize: 17,
    color: 'rgba(255,255,255,0.85)',
    fontWeight: '600',
    letterSpacing: 1,
    marginBottom: 40,
  },
  playBtn: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 64,
    paddingVertical: 18,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
    marginBottom: 28,
  },
  playText: {
    fontSize: 26,
    fontWeight: '900',
    color: '#4A90D9',
    letterSpacing: 2,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 24,
  },
  iconBtn: {
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 16,
    minWidth: 80,
  },
  iconBtnEmoji: {
    fontSize: 24,
    marginBottom: 4,
  },
  iconBtnLabel: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
  },
  bestBox: {
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 14,
  },
  bestLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.5,
  },
  bestScore: {
    color: '#FFE08A',
    fontSize: 28,
    fontWeight: '900',
  },
  floatingPlane: {
    position: 'absolute',
    top: H * 0.22,
    left: W * 0.5 - 32,
  },
});
