import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable, Modal } from 'react-native';
import { sound } from '@/lib/sound';
import { Avatar } from './Avatar';
import { loadLocalProfile } from '@/lib/player';

interface GameOverPopupProps {
  score: number;
  bestScore: number;
  result: { score: number; isTop10: boolean; rank: number | null } | null;
  onPlayAgain: () => void;
  onExit: () => void;
}

export function GameOverPopup({ score, bestScore, result, onPlayAgain, onExit }: GameOverPopupProps) {
  const profile = loadLocalProfile();
  const isNewBest = score >= bestScore && score > 0;

  const handlePlayAgain = () => {
    sound.play('click');
    onPlayAgain();
  };

  const handleExit = () => {
    sound.play('click');
    onExit();
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={handleExit}>
      <View style={styles.overlay}>
        <View style={styles.card}>
          <Text style={styles.gameOverTitle}>Game Over</Text>

          {isNewBest && (
            <View style={styles.newBestBadge}>
              <Text style={styles.newBestText}>★ NEW BEST!</Text>
            </View>
          )}

          <View style={styles.scoreRow}>
            <View style={styles.scoreCol}>
              <Text style={styles.scoreLabel}>SCORE</Text>
              <Text style={styles.scoreNum}>{score}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.scoreCol}>
              <Text style={styles.scoreLabel}>BEST</Text>
              <Text style={styles.bestNum}>{Math.max(bestScore, score)}</Text>
            </View>
          </View>

          {result && (
            <View style={styles.rankRow}>
              {result.isTop10 ? (
                <Text style={styles.rankText}>🎉 Top 10 Global!</Text>
              ) : result.rank ? (
                <Text style={styles.rankText}>Your Global Rank: #{result.rank}</Text>
              ) : null}
            </View>
          )}

          {profile && (
            <View style={styles.profileRow}>
              <Avatar seed={profile.avatar_seed} size={28} />
              <Text style={styles.profileName}>{profile.username}</Text>
            </View>
          )}

          <Pressable style={styles.playAgainBtn} onPress={handlePlayAgain}>
            <Text style={styles.playAgainText}>▶ Play Again</Text>
          </Pressable>
          <Pressable style={styles.menuBtn} onPress={handleExit}>
            <Text style={styles.menuText}>Main Menu</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    width: 340,
    backgroundColor: '#fff',
    borderRadius: 28,
    padding: 28,
    alignItems: 'center',
  },
  gameOverTitle: {
    fontSize: 32,
    fontWeight: '900',
    color: '#E85D4A',
    marginBottom: 8,
  },
  newBestBadge: {
    backgroundColor: '#FFE08A',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    marginBottom: 16,
  },
  newBestText: {
    color: '#B8860B',
    fontSize: 13,
    fontWeight: '800',
  },
  scoreRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 24,
    marginBottom: 16,
  },
  scoreCol: {
    alignItems: 'center',
  },
  scoreLabel: {
    color: '#999',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
  },
  scoreNum: {
    fontSize: 40,
    fontWeight: '900',
    color: '#1a1a2e',
  },
  bestNum: {
    fontSize: 40,
    fontWeight: '900',
    color: '#4A90D9',
  },
  divider: {
    width: 1,
    height: 50,
    backgroundColor: '#eee',
  },
  rankRow: {
    marginBottom: 12,
  },
  rankText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#5DBB63',
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 20,
  },
  profileName: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
  },
  playAgainBtn: {
    width: '100%',
    backgroundColor: '#4A90D9',
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 10,
  },
  playAgainText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '800',
  },
  menuBtn: {
    width: '100%',
    paddingVertical: 12,
    alignItems: 'center',
  },
  menuText: {
    color: '#999',
    fontSize: 15,
    fontWeight: '600',
  },
});
