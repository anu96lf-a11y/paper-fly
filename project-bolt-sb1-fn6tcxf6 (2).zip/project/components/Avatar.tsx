import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface AvatarProps {
  seed: string;
  size: number;
}

const PALETTES: Record<string, [string, string]> = {
  plane: ['#4A90D9', '#7AB8E8'],
  rocket: ['#E85D4A', '#F5A582'],
  bird: ['#F5C842', '#FFE08A'],
  star: ['#B08FD9', '#D9C2F0'],
  cloud: ['#6FB8C9', '#A8DAE5'],
  kite: ['#5DBB63', '#A3E0A8'],
  eagle: ['#C97840', '#E8B585'],
  comet: ['#D9534F', '#F5B5B0'],
};

function hashSeed(seed: string): number {
  let h = 0;
  for (let i = 0; i < seed.length; i++) {
    h = (h * 31 + seed.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

export function Avatar({ seed, size }: AvatarProps) {
  const prefix = seed.split('-')[0] ?? 'plane';
  const [c1, c2] = PALETTES[prefix] ?? PALETTES.plane;
  const h = hashSeed(seed);
  const initials = String.fromCharCode(65 + (h % 26)) + String.fromCharCode(65 + ((h >> 5) % 26));

  return (
    <View
      style={[
        styles.wrap,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: c1,
        },
      ]}
    >
      <View style={[styles.inner, { width: size * 0.7, height: size * 0.7, borderRadius: size * 0.35, backgroundColor: c2 }]} />
      <Text style={[styles.initials, { fontSize: size * 0.34 }]}>{initials}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  inner: {
    position: 'absolute',
    opacity: 0.6,
  },
  initials: {
    color: '#fff',
    fontWeight: '700',
    letterSpacing: -0.5,
  },
});
