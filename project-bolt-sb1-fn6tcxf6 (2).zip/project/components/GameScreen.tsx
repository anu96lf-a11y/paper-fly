import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, Pressable, Text } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
  interpolate,
  runOnJS,
  cancelAnimation,
  type SharedValue,
} from 'react-native-reanimated';
import Svg, { Circle, Path, Line } from 'react-native-svg';
import { PaperPlane } from '@/components/PaperPlane';
import { ParallaxBackground } from '@/components/ParallaxBackground';
import { BannerAd } from '@/components/BannerAd';
import { RevivePopup } from '@/components/RevivePopup';
import { GameOverPopup } from '@/components/GameOverPopup';
import {
  PHYSICS,
  OBSTACLES,
  STAGES,
  STAGE_THEMES,
} from '@/lib/gameConfig';
import type { Obstacle, StageId, GameState } from '@/lib/types';
import { sound } from '@/lib/sound';
import { ads } from '@/lib/ads';
import { submitScore, loadLocalProfile } from '@/lib/player';

const { width: W, height: H } = Dimensions.get('window');
const GROUND_H = 70;
const PLAY_H = H - GROUND_H;

interface GameScreenProps {
  onExit: () => void;
}

export function GameScreen({ onExit }: GameScreenProps) {
  const [status, setStatus] = useState<GameState['status']>('playing');
  const [score, setScore] = useState(0);
  const [bestScore, setBestScore] = useState(() => loadLocalProfile()?.best_score ?? 0);
  const [stage, setStage] = useState<StageId>(1);
  const [showRevive, setShowRevive] = useState(false);
  const [showGameOver, setShowGameOver] = useState(false);
  const [lastResult, setLastResult] = useState<{ score: number; isTop10: boolean; rank: number | null } | null>(null);

  // Physics refs
  const planeY = useSharedValue(PLAY_H * 0.4);
  const planeVY = useSharedValue(0);
  const planeRotation = useSharedValue(0);
  const speedSV = useSharedValue(OBSTACLES.speedBase);
  const stageTimeSV = useSharedValue(0);
  const stageSV = useSharedValue<StageId>(1);
  const lastTimeRef = useRef<number>(0);
  const rafRef = useRef<number | null>(null);
  const obstaclesRef = useRef<Obstacle[]>([]);
  const nextObstacleId = useRef(0);
  const scoreRef = useRef(0);
  const reviveUsedRef = useRef(false);
  const gameoverCountRef = useRef(0);
  const statusRef = useRef<GameState['status']>('playing');
  const scoreSV = useSharedValue(0);
  const obstacleTick = useSharedValue(0);

  const theme = STAGE_THEMES[stage];

  const playSound = useCallback((s: 'flap' | 'pass' | 'crash' | 'transition') => {
    sound.play(s);
  }, []);

  const setStatusSafe = useCallback((s: GameState['status']) => {
    statusRef.current = s;
    setStatus(s);
  }, []);

  const handleCrash = useCallback(() => {
    if (statusRef.current !== 'playing') return;
    playSound('crash');
    cancelAnimation(planeRotation);
    planeRotation.value = withTiming(90, { duration: 300 });
    planeVY.value = 0;

    if (!reviveUsedRef.current) {
      setStatusSafe('revive-prompt');
      setShowRevive(true);
    } else {
      finishGame();
    }
  }, [playSound, setStatusSafe]);

  const finishGame = useCallback(async () => {
    setStatusSafe('gameover');
    gameoverCountRef.current += 1;
    const finalScore = scoreRef.current;
    setLastResult(null);
    setShowGameOver(true);

    const result = await submitScore(finalScore, stageSV.value);
    setLastResult({ score: finalScore, isTop10: result.isTop10, rank: result.rank });
    if (finalScore > bestScore) setBestScore(finalScore);

    if (gameoverCountRef.current % 3 === 0) {
      ads.loadInterstitial().then(() => ads.showInterstitial());
    }
  }, [bestScore, setStatusSafe]);

  const gameLoop = useCallback((time: number) => {
    if (statusRef.current !== 'playing') {
      lastTimeRef.current = time;
      rafRef.current = requestAnimationFrame(gameLoop);
      return;
    }

    const last = lastTimeRef.current || time;
    const dt = Math.min((time - last) / 1000, 0.033);
    lastTimeRef.current = time;

    // Physics — lighter, smoother paper-plane feel
    planeVY.value += PHYSICS.gravity * dt;
    if (planeVY.value > PHYSICS.maxFallSpeed) planeVY.value = PHYSICS.maxFallSpeed;
    planeY.value += planeVY.value * dt;

    // Rotation based on velocity
    planeRotation.value = interpolate(
      planeVY.value,
      [PHYSICS.flapVelocity, 0, PHYSICS.maxFallSpeed],
      [PHYSICS.rotationUp, 0, PHYSICS.rotationDown],
    );

    // Progressive difficulty: speed ramps with score
    const currentSpeed = Math.min(
      OBSTACLES.speedBase + scoreRef.current * OBSTACLES.speedRamp,
      OBSTACLES.speedMax,
    );
    speedSV.value = currentSpeed;

    // Stage progression
    stageTimeSV.value += dt;
    if (stageTimeSV.value >= STAGES.durationSec) {
      stageTimeSV.value = 0;
      const next = ((stageSV.value % 4) + 1) as StageId;
      stageSV.value = next;
      runOnJS(setStage)(next);
      runOnJS(playSound)('transition');
    }

    // Move obstacles
    const moveBy = currentSpeed * dt;
    const obs = obstaclesRef.current;
    for (let i = 0; i < obs.length; i++) {
      obs[i].x -= moveBy;
      if (obs[i].rotating) obs[i].rotation += 180 * dt;
    }

    // Progressive spacing & gap — shrink gradually with score
    const currentSpacing = Math.max(
      OBSTACLES.spacingMin,
      OBSTACLES.spacing - scoreRef.current * OBSTACLES.spacingShrinkRate,
    );
    const currentGap = Math.max(
      OBSTACLES.gapSizeMin,
      OBSTACLES.gapSizeBase - scoreRef.current * OBSTACLES.gapShrinkRate,
    );

    // Spawn obstacles
    const lastObs = obs[obs.length - 1];
    if (!lastObs || lastObs.x < W - currentSpacing) {
      const gapY = 80 + Math.random() * (PLAY_H - currentGap - 160);
      const variants: Obstacle['variant'][] = ['pipe', 'building', 'drum', 'cloud'];
      const variant = variants[(stageSV.value - 1) % 4];
      obs.push({
        id: nextObstacleId.current++,
        x: W + 40,
        gapY,
        gapSize: currentGap,
        passed: false,
        variant,
        rotating: stageSV.value === 3 && Math.random() > 0.5,
        rotation: 0,
      });
    }

    // Remove off-screen obstacles
    obstaclesRef.current = obs.filter((o) => o.x > -OBSTACLES.width - 20);

    // Collision + scoring
    const planeLeft = PHYSICS.planeX - PHYSICS.planeSize * 0.35;
    const planeRight = PHYSICS.planeX + PHYSICS.planeSize * 0.35;
    const planeTop = planeY.value - PHYSICS.planeSize * 0.3;
    const planeBottom = planeY.value + PHYSICS.planeSize * 0.3;

    let crashed = false;

    // Ground/ceiling collision
    if (planeBottom >= PLAY_H - 4 || planeTop <= 4) {
      crashed = true;
    }

    for (let i = 0; i < obstaclesRef.current.length && !crashed; i++) {
      const o = obstaclesRef.current[i];
      const oLeft = o.x;
      const oRight = o.x + OBSTACLES.width;

      if (planeRight > oLeft && planeLeft < oRight) {
        const gapTop = o.gapY;
        const gapBottom = o.gapY + o.gapSize;
        if (planeTop < gapTop || planeBottom > gapBottom) {
          crashed = true;
        }
      }

      if (!o.passed && oRight < PHYSICS.planeX) {
        o.passed = true;
        scoreRef.current += 1;
        scoreSV.value = scoreRef.current;
        runOnJS(setScore)(scoreRef.current);
        runOnJS(playSound)('pass');
      }
    }

    obstacleTick.value += 1;

    if (crashed) {
      runOnJS(handleCrash)();
    }

    rafRef.current = requestAnimationFrame(gameLoop);
  }, [handleCrash, playSound]);

  const flap = useCallback(() => {
    if (statusRef.current === 'playing') {
      planeVY.value = PHYSICS.flapVelocity;
      playSound('flap');
    }
  }, [playSound]);

  // Start game loop
  useEffect(() => {
    sound.initFromStorage();
    ads.loadRewarded();
    ads.loadInterstitial();
    lastTimeRef.current = 0;
    rafRef.current = requestAnimationFrame(gameLoop);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [gameLoop]);

  const resetGame = useCallback(() => {
    planeY.value = PLAY_H * 0.4;
    planeVY.value = 0;
    planeRotation.value = 0;
    scoreRef.current = 0;
    scoreSV.value = 0;
    stageTimeSV.value = 0;
    stageSV.value = 1;
    speedSV.value = OBSTACLES.speedBase;
    obstaclesRef.current = [];
    nextObstacleId.current = 0;
    reviveUsedRef.current = false;
    setScore(0);
    setStage(1);
    setShowRevive(false);
    setShowGameOver(false);
    setLastResult(null);
    setStatusSafe('playing');
  }, [setStatusSafe]);

  const handleRevive = useCallback(() => {
    ads.showRewarded((event) => {
      if (event === 'rewarded') {
        obstaclesRef.current = obstaclesRef.current.filter((o) => o.x > W + 50);
        planeY.value = PLAY_H * 0.4;
        planeVY.value = 0;
        planeRotation.value = 0;
        reviveUsedRef.current = true;
        setShowRevive(false);
        setStatusSafe('playing');
        ads.loadRewarded();
      }
    });
  }, [setStatusSafe]);

  const handleDeclineRevive = useCallback(() => {
    setShowRevive(false);
    finishGame();
  }, [finishGame]);

  const handlePlayAgain = useCallback(() => {
    resetGame();
  }, [resetGame]);

  const planeAnimStyle = useAnimatedStyle(() => ({
    transform: [
      { translateY: planeY.value },
      { rotate: `${planeRotation.value}deg` },
    ],
  }));

  return (
    <View style={styles.container}>
      <ParallaxBackground stage={stage} scrollSpeed={speedSV.value} />

      {/* Touch layer */}
      {(status === 'playing' || status === 'revive-prompt') && (
        <Pressable style={StyleSheet.absoluteFill} onPress={flap} />
      )}

      {/* Obstacles */}
      <ObstacleLayer obstaclesRef={obstaclesRef} tick={obstacleTick} stage={stage} />

      {/* Paper plane */}
      <Animated.View
        style={[styles.plane, { left: PHYSICS.planeX - PHYSICS.planeSize / 2 }, planeAnimStyle]}
        pointerEvents="none"
      >
        <PaperPlane size={PHYSICS.planeSize} rotation={0} color="#FFFFFF" accent={theme.obstacleAccent} />
      </Animated.View>

      {/* Wind trail — multi-particle */}
      <WindTrail planeY={planeY} planeX={PHYSICS.planeX} active={status === 'playing'} />

      {/* HUD */}
      <View style={styles.hud} pointerEvents="none">
        <View style={styles.scoreBox}>
          <Text style={styles.scoreLabel}>SCORE</Text>
          <Text style={styles.scoreValue}>{score}</Text>
        </View>
        <View style={styles.scoreBox}>
          <Text style={styles.scoreLabel}>BEST</Text>
          <Text style={styles.bestValue}>{bestScore}</Text>
        </View>
        <View style={styles.stageBadge}>
          <Text style={styles.stageText}>{STAGE_THEMES[stage].name}</Text>
        </View>
      </View>

      {/* Exit button */}
      <Pressable style={styles.exitBtn} onPress={onExit} hitSlop={8}>
        <Text style={styles.exitText}>✕</Text>
      </Pressable>

      {/* Banner ad */}
      <View style={styles.bannerContainer} pointerEvents="none">
        <BannerAd />
      </View>

      {/* Revive popup */}
      {showRevive && (
        <RevivePopup onWatch={handleRevive} onDecline={handleDeclineRevive} />
      )}

      {/* Game over popup */}
      {showGameOver && (
        <GameOverPopup
          score={scoreRef.current}
          bestScore={bestScore}
          result={lastResult}
          onPlayAgain={handlePlayAgain}
          onExit={onExit}
        />
      )}
    </View>
  );
}

/** Obstacle rendering layer — reads from ref and re-renders on tick */
const ObstacleLayer = React.memo(function ObstacleLayer({
  obstaclesRef,
  stage,
}: {
  obstaclesRef: React.RefObject<Obstacle[]>;
  tick: SharedValue<number>;
  stage: StageId;
}) {
  const theme = STAGE_THEMES[stage];
  const [, setLocal] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setLocal((v) => v + 1);
    }, 16);
    return () => clearInterval(interval);
  }, []);

  const obstacles = obstaclesRef.current;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {obstacles.map((o) => {
        const gapTop = o.gapY;
        const gapBottom = o.gapY + o.gapSize;
        const topH = gapTop;
        const bottomH = PLAY_H - gapBottom;
        return (
          <React.Fragment key={o.id}>
            {/* Top obstacle */}
            <View
              style={[
                styles.obstacle,
                {
                  left: o.x,
                  top: 0,
                  width: OBSTACLES.width,
                  height: topH,
                  backgroundColor: theme.obstacleColor,
                  borderBottomWidth: 4,
                  borderBottomColor: theme.obstacleAccent,
                },
              ]}
            >
              {o.rotating && (
                <Svg style={StyleSheet.absoluteFill} width={OBSTACLES.width} height={topH}>
                  <Line
                    x1={OBSTACLES.width / 2}
                    y1={topH - 20}
                    x2={OBSTACLES.width / 2}
                    y2={topH}
                    stroke={theme.accent}
                    strokeWidth="3"
                  />
                </Svg>
              )}
            </View>
            {/* Bottom obstacle */}
            <View
              style={[
                styles.obstacle,
                {
                  left: o.x,
                  top: gapBottom,
                  width: OBSTACLES.width,
                  height: bottomH,
                  backgroundColor: theme.obstacleColor,
                  borderTopWidth: 4,
                  borderTopColor: theme.obstacleAccent,
                },
              ]}
            >
              {o.rotating && (
                <View style={[styles.fanBlade, { top: 10 }]}>
                  <Svg width={30} height={30} viewBox="0 0 30 30">
                    <Circle cx={15} cy={15} r={3} fill={theme.accent} />
                    <Path d="M15,15 L15,2 Q20,8 15,15 Z" fill={theme.accent} opacity={0.7} />
                    <Path d="M15,15 L28,15 Q22,20 15,15 Z" fill={theme.accent} opacity={0.7} />
                    <Path d="M15,15 L15,28 Q10,22 15,15 Z" fill={theme.accent} opacity={0.7} />
                    <Path d="M15,15 L2,15 Q8,10 15,15 Z" fill={theme.accent} opacity={0.7} />
                  </Svg>
                </View>
              )}
            </View>
          </React.Fragment>
        );
      })}
    </View>
  );
});

/** Multi-particle wind trail behind the plane */
function WindTrail({ planeY, planeX, active }: { planeY: SharedValue<number>; planeX: number; active: boolean }) {
  const trailStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: planeY.value }, { translateX: planeX - 34 }],
    opacity: active ? 0.55 : 0,
  }));

  return (
    <Animated.View style={[styles.trailWrap, trailStyle]} pointerEvents="none">
      <Svg width={34} height={36} viewBox="0 0 34 36">
        {/* Main trail curl */}
        <Path d="M0,18 Q8,10 20,18 Q26,22 32,16" stroke="#FFFFFF" strokeWidth="2.5" fill="none" opacity={0.6} strokeLinecap="round" />
        {/* Secondary trail */}
        <Path d="M0,22 Q6,16 16,22 Q22,25 28,20" stroke="#FFFFFF" strokeWidth="1.8" fill="none" opacity={0.4} strokeLinecap="round" />
        {/* Small particle dots */}
        <Circle cx={6} cy={14} r={1.5} fill="#FFFFFF" opacity={0.5} />
        <Circle cx={14} cy={24} r={1} fill="#FFFFFF" opacity={0.4} />
        <Circle cx={22} cy={12} r={1.2} fill="#FFFFFF" opacity={0.45} />
        <Circle cx={28} cy={26} r={0.8} fill="#FFFFFF" opacity={0.35} />
      </Svg>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#7EC8E3',
  },
  plane: {
    position: 'absolute',
    top: -PHYSICS.planeSize / 2,
  },
  hud: {
    position: 'absolute',
    top: 50,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'flex-start',
    gap: 20,
    zIndex: 10,
  },
  scoreBox: {
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.25)',
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 16,
  },
  scoreLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.5,
  },
  scoreValue: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: '900',
  },
  bestValue: {
    color: '#FFE08A',
    fontSize: 24,
    fontWeight: '800',
  },
  stageBadge: {
    position: 'absolute',
    top: 0,
    right: 16,
    backgroundColor: 'rgba(0,0,0,0.3)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  stageText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
  },
  obstacle: {
    position: 'absolute',
  },
  fanBlade: {
    position: 'absolute',
    left: OBSTACLES.width / 2 - 15,
  },
  exitBtn: {
    position: 'absolute',
    top: 50,
    left: 16,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0,0,0,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 20,
  },
  exitText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
  bannerContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 15,
  },
  trailWrap: {
    position: 'absolute',
    top: -18,
  },
});
