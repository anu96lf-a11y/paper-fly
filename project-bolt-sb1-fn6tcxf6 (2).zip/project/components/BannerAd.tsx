import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ads } from '@/lib/ads';

/**
 * Banner ad displayed at the bottom of menu/UI screens.
 * On native this renders a real AdMob banner; on web preview it shows a
 * labeled placeholder bar so the layout is accurate.
 */
export function BannerAd() {
  React.useEffect(() => {
    ads.showBanner();
    return () => ads.hideBanner();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.bar}>
        <Text style={styles.label}>AdMob Banner</Text>
        <Text style={styles.sub}>320×50 test ad unit</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 50,
    width: '100%',
    backgroundColor: '#1a1a2e',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bar: {
    width: 320,
    maxWidth: '100%',
    height: 50,
    backgroundColor: '#2a2a4e',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#4a4a6e',
  },
  label: {
    color: '#8a8aae',
    fontSize: 12,
    fontWeight: '700',
  },
  sub: {
    color: '#5a5a7e',
    fontSize: 9,
    marginTop: 2,
  },
});
