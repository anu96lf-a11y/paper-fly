import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, TextInput, Modal, ActivityIndicator } from 'react-native';
import { Avatar } from '@/components/Avatar';
import { sound } from '@/lib/sound';
import { ensureProfile, randomAvatarSeed, saveLocalProfile } from '@/lib/player';

interface ProfileSetupProps {
  visible: boolean;
  onDone: () => void;
}

export function ProfileSetup({ visible, onDone }: ProfileSetupProps) {
  const [name, setName] = useState('');
  const [avatarSeed, setAvatarSeed] = useState(() => randomAvatarSeed());
  const [saving, setSaving] = useState(false);

  const handleShuffle = () => {
    sound.play('click');
    setAvatarSeed(randomAvatarSeed());
  };

  const handleStart = async () => {
    const trimmed = name.trim() || `Pilot${Math.floor(Math.random() * 9000) + 1000}`;
    setSaving(true);
    await ensureProfile(trimmed);
    setSaving(false);
    sound.play('click');
    onDone();
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onDone}>
      <View style={styles.overlay}>
        <View style={styles.card}>
          <Text style={styles.title}>Welcome, Pilot!</Text>
          <Text style={styles.subtitle}>Create your profile to join the global leaderboard</Text>

          <View style={styles.avatarRow}>
            <Avatar seed={avatarSeed} size={72} />
            <Pressable style={styles.shuffleBtn} onPress={handleShuffle}>
              <Text style={styles.shuffleText}>🎲 Shuffle</Text>
            </Pressable>
          </View>

          <Text style={styles.label}>Your Name</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            maxLength={16}
            placeholder="Enter pilot name..."
            placeholderTextColor="#999"
            autoCapitalize="words"
            autoCorrect={false}
          />

          <Pressable style={styles.startBtn} onPress={handleStart} disabled={saving}>
            {saving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.startText}>Start Flying ✈</Text>
            )}
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    width: 340,
    backgroundColor: '#fff',
    borderRadius: 28,
    padding: 28,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#1a1a2e',
    marginBottom: 6,
  },
  subtitle: {
    fontSize: 14,
    color: '#777',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  avatarRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 24,
  },
  shuffleBtn: {
    backgroundColor: '#E8F0FE',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
  },
  shuffleText: {
    color: '#4A90D9',
    fontSize: 14,
    fontWeight: '700',
  },
  label: {
    alignSelf: 'flex-start',
    color: '#999',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
    marginBottom: 8,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 17,
    color: '#1a1a2e',
    marginBottom: 24,
  },
  startBtn: {
    width: '100%',
    backgroundColor: '#4A90D9',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
  },
  startText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '800',
  },
});
