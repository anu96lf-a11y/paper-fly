/*
# Create Paper Fly leaderboard tables

1. New Tables
- `players`: stores per-device player profile (username, avatar seed, best score).
  - `id` (uuid, primary key)
  - `device_id` (text, unique) — identifies the player's device without requiring auth
  - `username` (text, not null)
  - `avatar_seed` (text) — seed used to render a deterministic avatar on the client
  - `best_score` (int, default 0)
  - `created_at`, `updated_at` (timestamps)
- `scores`: append-only score submissions for ranking history.
  - `id` (uuid, primary key)
  - `device_id` (text, not null) — links to players.device_id (no FK to keep it loose)
  - `username` (text, not null) — denormalized snapshot for leaderboard display
  - `avatar_seed` (text)
  - `score` (int, not null)
  - `stage_reached` (int, default 1)
  - `created_at` (timestamp)

2. Security
- Enable RLS on both tables.
- This is a no-auth app (no sign-in screen); all policies use `TO anon, authenticated`
  so the anon-key client can read the global leaderboard and submit scores.
- SELECT is public (global leaderboard is shared).
- INSERT is open (anyone can submit a score / create a profile).
- UPDATE is restricted to rows matching the requester's device_id (for best_score updates).
- DELETE is denied (no policy) — scores are permanent history.

3. Notes
- `device_id` is generated client-side and persisted in AsyncStorage; it is NOT a secure
  identity, but it is sufficient for a casual hyper-casual game leaderboard and lets us
  avoid a full auth flow.
*/

CREATE TABLE IF NOT EXISTS players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  username text NOT NULL,
  avatar_seed text NOT NULL DEFAULT '',
  best_score integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text NOT NULL,
  username text NOT NULL,
  avatar_seed text,
  score integer NOT NULL,
  stage_reached integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS scores_score_desc_idx ON scores (score DESC);
CREATE INDEX IF NOT EXISTS scores_device_id_idx ON scores (device_id);
CREATE INDEX IF NOT EXISTS players_device_id_idx ON players (device_id);

ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE scores ENABLE ROW LEVEL SECURITY;

-- players policies
DROP POLICY IF EXISTS "anon_select_players" ON players;
CREATE POLICY "anon_select_players" ON players FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_players" ON players;
CREATE POLICY "anon_insert_players" ON players FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_own_player" ON players;
CREATE POLICY "anon_update_own_player" ON players FOR UPDATE
  TO anon, authenticated
  USING (device_id = current_setting('app.device_id', true))
  WITH CHECK (device_id = current_setting('app.device_id', true));

-- scores policies
DROP POLICY IF EXISTS "anon_select_scores" ON scores;
CREATE POLICY "anon_select_scores" ON scores FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_scores" ON scores;
CREATE POLICY "anon_insert_scores" ON scores FOR INSERT
  TO anon, authenticated WITH CHECK (true);
