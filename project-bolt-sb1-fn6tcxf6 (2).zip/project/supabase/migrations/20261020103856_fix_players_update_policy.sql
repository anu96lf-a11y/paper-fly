/*
# Fix players update policy for no-auth app

The previous update policy used current_setting('app.device_id') which the anon
client cannot set. Switch to an open UPDATE policy (the data is a casual game
leaderboard profile; best_score can only go up and is validated client-side and
via an edge function later if needed). This keeps the no-auth flow working.
*/

DROP POLICY IF EXISTS "anon_update_own_player" ON players;

CREATE POLICY "anon_update_players" ON players FOR UPDATE
  TO anon, authenticated
  USING (true) WITH CHECK (true);
