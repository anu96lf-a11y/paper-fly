import React, { useState, useEffect } from 'react';
import { StyleSheet } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { MainMenu } from '@/components/MainMenu';
import { IntroAnimation } from '@/components/IntroAnimation';
import { GameScreen } from '@/components/GameScreen';
import { LeaderboardScreen } from '@/components/LeaderboardScreen';
import { SettingsScreen } from '@/components/SettingsScreen';
import { ProfileSetup } from '@/components/ProfileSetup';
import { ensureProfile, loadLocalProfile } from '@/lib/player';

type Screen = 'menu' | 'intro' | 'game' | 'leaderboard' | 'settings';

export default function IndexScreen() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [needsProfile, setNeedsProfile] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      const existing = loadLocalProfile();
      if (!existing) {
        setNeedsProfile(true);
      } else {
        await ensureProfile(existing.username);
      }
      setReady(true);
    })();
  }, []);

  const handleProfileDone = () => {
    setNeedsProfile(false);
  };

  const handlePlay = () => {
    setScreen('intro');
  };

  const handleIntroComplete = () => {
    setScreen('game');
  };

  const handleExitGame = () => {
    setScreen('menu');
  };

  if (!ready) {
    return null;
  }

  return (
    <SafeAreaProvider>
      {screen === 'menu' && (
        <MainMenu
          onPlay={handlePlay}
          onLeaderboard={() => setScreen('leaderboard')}
          onSettings={() => setScreen('settings')}
        />
      )}

      {screen === 'intro' && <IntroAnimation onComplete={handleIntroComplete} />}

      {screen === 'game' && <GameScreen onExit={handleExitGame} />}

      {screen === 'leaderboard' && <LeaderboardScreen onBack={() => setScreen('menu')} />}

      {screen === 'settings' && <SettingsScreen onBack={() => setScreen('menu')} />}

      <ProfileSetup visible={needsProfile} onDone={handleProfileDone} />
    </SafeAreaProvider>
  );
}
