# Paper Fly — PWA & Android APK Build Guide

This project is configured as a **Progressive Web App (PWA)** and can be converted
to a native **Android APK** using Capacitor JS. Follow the steps below.

---

## Part 1: PWA (Progressive Web App)

The project is already fully configured as a PWA. The following files make it work:

| File | Purpose |
|------|---------|
| `public/manifest.json` | Web app manifest — title, icons, fullscreen mode, portrait orientation |
| `public/sw.js` | Service worker — caches the app shell for offline play |
| `public/icon-192.png` | PWA icon (192x192) |
| `public/icon-512.png` | PWA icon (512x512) |
| `public/icon-maskable-512.png` | Maskable icon for Android adaptive icons |
| `scripts/pwa-postbuild.js` | Post-build script that injects PWA meta tags into the built HTML |
| `capacitor.config.ts` | Capacitor configuration for Android APK |
| `app.json` | Expo config — renamed to "Paper Fly", web output set to single-file |

### Build the PWA

```bash
npm run build:pwa
```

This runs two steps:
1. `expo export --platform web` — builds the web app into `dist/`
2. `node scripts/pwa-postbuild.js` — injects PWA meta tags, copies manifest/icons/service worker into `dist/`

### Test the PWA locally

Serve the `dist/` folder with any static server. Service workers require HTTP(S),
not `file://`:

```bash
npx serve dist
# or
npx http-server dist -p 3000
```

Open `http://localhost:3000` in Chrome. Use **DevTools > Application > Manifest**
to verify the PWA is detected, and **DevTools > Application > Service Workers**
to confirm the service worker is registered.

### Install on phone (PWA)

1. Open the deployed URL in Chrome on Android (or Safari on iOS).
2. Chrome: tap the menu (⋮) → **Install app** / **Add to Home screen**.
3. Safari: tap Share → **Add to Home Screen**.
4. The app launches fullscreen in portrait mode — no browser chrome.

### PWA features

- **Fullscreen display**: No browser address bar or navigation.
- **Portrait orientation lock**: App stays in portrait on all devices.
- **Offline play**: Service worker caches the app shell. The game runs fully
  client-side. Scores sync to Supabase when the network returns.
- **Home screen icon**: Custom Paper Fly icon appears on the phone's home screen.
- **Touch controls**: Tap anywhere to fly. Touch events are optimized for mobile.
- **Sound**: Web Audio API works in PWA mode after first user interaction.

---

## Part 2: Android APK with Capacitor

Capacitor wraps the PWA into a native Android app. The `capacitor.config.ts`
file is pre-configured with:
- **App ID**: `com.paperfly.game`
- **App name**: Paper Fly
- **Web directory**: `dist` (the PWA build output)

### Prerequisites

You need a local development machine with:
- **Node.js** 18+ and npm
- **Android Studio** (includes Android SDK) — download from
  https://developer.android.com/studio
- **Java JDK 17** (bundled with Android Studio, or install separately)

> Bolt's in-browser preview cannot build native Android APKs.
> You must run these steps on your own computer (e.g., in VS Code or a terminal).

### Step-by-step: Build the APK

#### 1. Export and open the project locally

Download or clone this project to your computer. Open a terminal in the project root.

#### 2. Install dependencies

```bash
npm install
```

#### 3. Build the PWA (web output → dist/)

```bash
npm run build:pwa
```

This creates `dist/` with the full PWA: HTML, JS, manifest, icons, service worker.

#### 4. Add the Android platform (first time only)

```bash
npx cap add android
```

This creates the `android/` directory — a native Android Studio project that
wraps your web app.

#### 5. Sync the web build into the Android project

```bash
npm run cap:sync
```

This runs `build:pwa` + `cap sync android`, copying `dist/` into the Android
project and updating native plugins.

#### 6. Open in Android Studio

```bash
npm run cap:open
```

Android Studio opens with the Paper Fly project loaded.

#### 7. Build the APK

In Android Studio:

**Debug APK (for testing):**
- Menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
- Wait for the build to finish.
- Click "locate" in the notification to find the APK file.
- Output path: `android/app/build/outputs/apk/debug/app-debug.apk`

**Release APK (for distribution):**
- Menu: **Build > Generate Signed Bundle / APK**
- Choose **APK**, then click Next.
- Create or select a keystore (save it safely — you need the same keystore
  for all future updates).
- Select **release** build variant.
- Click Finish. Output: `android/app/build/outputs/apk/release/app-release.apk`

#### 8. Install on your phone

**Option A — USB (debug APK):**
- Enable **Developer Options** and **USB Debugging** on your Android phone.
- Connect via USB.
- In Android Studio, select your device and click the green **Run ▶** button.

**Option B — Manual install:**
- Copy the `.apk` file to your phone (via USB, email, or cloud storage).
- On your phone, open the APK file. You may need to enable
  **Settings > Security > Install unknown apps** for your file manager.
- Tap **Install**.

### Quick reference commands

```bash
npm run build:pwa     # Build PWA into dist/
npm run cap:sync      # Build PWA + sync to Android project
npm run cap:open      # Open Android Studio
npm run cap:run       # Build + run on connected Android device
npm run android:build # Full pipeline: build PWA, sync, open Android Studio
```

---

## Part 3: Configuration reference

### app.json (Expo web config)

```json
"web": {
  "bundler": "metro",
  "output": "single",
  "name": "Paper Fly",
  "shortName": "PaperFly",
  "display": "fullscreen",
  "orientation": "portrait"
}
```

### capacitor.config.ts

```typescript
{
  appId: 'com.paperfly.game',
  appName: 'Paper Fly',
  webDir: 'dist',
  server: { androidScheme: 'https' },
  android: { webContentsDebuggingEnabled: false },
}
```

### manifest.json key settings

- `display: "fullscreen"` — no browser UI at all
- `display_override: ["fullscreen", "standalone", "minimal-ui"]` — fallback chain
- `orientation: "portrait"` — locks to portrait on all devices
- `theme_color: "#4A90D9"` — Android status bar color
- `background_color: "#7EC8E3"` — splash background

---

## Troubleshooting

**Service worker not registering?**
- Must be served over `http://localhost` or HTTPS. `file://` won't work.
- Check DevTools > Application > Service Workers for errors.

**Blank screen in Capacitor?**
- Run `npm run cap:sync` after every `build:pwa` to update the bundled web files.
- Enable `webContentsDebuggingEnabled: true` in `capacitor.config.ts` for debugging.

**Sound not working on Android?**
- Web Audio requires a user gesture (tap) before audio can play.
- The game plays a "click" sound on the Play button tap, which unlocks audio.

**APK too large?**
- The JS bundle is ~2MB. This is normal for a React Native web app.
- Enable code splitting or reduce assets if size is critical.

**Want to publish to Google Play?**
- Build a **signed release APK** (Step 7 above).
- Create a Google Play Developer account ($25 one-time fee).
- Upload the APK at https://play.google.com/console
- Fill in the store listing, screenshots, and privacy policy.

---

## File summary

```
project/
├── app.json                    # Expo config (renamed to Paper Fly)
├── capacitor.config.ts         # Capacitor Android config
├── public/
│   ├── manifest.json           # PWA manifest (fullscreen, portrait)
│   ├── sw.js                   # Service worker (offline caching)
│   ├── icon-192.png            # PWA icon 192x192
│   ├── icon-512.png            # PWA icon 512x512
│   └── icon-maskable-512.png   # Adaptive icon for Android
├── scripts/
│   └── pwa-postbuild.js        # Injects PWA tags into dist/index.html
└── dist/                       # Build output (after npm run build:pwa)
```
