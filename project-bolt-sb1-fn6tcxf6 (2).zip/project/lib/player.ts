import { supabase } from './supabase';
import type { PlayerProfile, ScoreRow } from './types';

const PROFILE_KEY = 'paperfly_profile_v1';
const DEVICE_KEY = 'paperfly_device_id_v1';

function getStorage(): Storage | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage;
    }
  } catch {
    // ignore
  }
  return null;
}

function generateId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'dev-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function getDeviceId(): string {
  const storage = getStorage();
  if (!storage) return generateId();
  let id = storage.getItem(DEVICE_KEY);
  if (!id) {
    id = generateId();
    storage.setItem(DEVICE_KEY, id);
  }
  return id;
}

const AVATAR_SEEDS = ['plane', 'rocket', 'bird', 'star', 'cloud', 'kite', 'eagle', 'comet'];

export function randomAvatarSeed(): string {
  return AVATAR_SEEDS[Math.floor(Math.random() * AVATAR_SEEDS.length)] + '-' + Math.floor(Math.random() * 1000);
}

export function loadLocalProfile(): PlayerProfile | null {
  const storage = getStorage();
  if (!storage) return null;
  const raw = storage.getItem(PROFILE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as PlayerProfile;
  } catch {
    return null;
  }
}

export function saveLocalProfile(profile: PlayerProfile): void {
  const storage = getStorage();
  if (!storage) return;
  storage.setItem(PROFILE_KEY, JSON.stringify(profile));
}

export async function ensureProfile(username?: string): Promise<PlayerProfile> {
  const deviceId = getDeviceId();
  const existing = loadLocalProfile();
  if (existing && !username) return existing;

  const name = (username ?? existing?.username ?? '').trim() || `Pilot${Math.floor(Math.random() * 9000) + 1000}`;
  const avatarSeed = existing?.avatar_seed ?? randomAvatarSeed();
  const bestScore = existing?.best_score ?? 0;

  const profile: PlayerProfile = {
    device_id: deviceId,
    username: name,
    avatar_seed: avatarSeed,
    best_score: bestScore,
  };

  const { error } = await supabase
    .from('players')
    .upsert(profile, { onConflict: 'device_id' });

  if (error) {
    saveLocalProfile(profile);
    return profile;
  }

  saveLocalProfile(profile);
  return profile;
}

export async function submitScore(score: number, stageReached: number): Promise<{ isTop10: boolean; rank: number | null }> {
  const profile = loadLocalProfile();
  if (!profile) return { isTop10: false, rank: null };

  const { error: insertError } = await supabase.from('scores').insert({
    device_id: profile.device_id,
    username: profile.username,
    avatar_seed: profile.avatar_seed,
    score,
    stage_reached: stageReached,
  });

  if (insertError) {
    return { isTop10: false, rank: null };
  }

  if (score > profile.best_score) {
    profile.best_score = score;
    saveLocalProfile(profile);
    await supabase
      .from('players')
      .update({ best_score: score, username: profile.username, avatar_seed: profile.avatar_seed })
      .eq('device_id', profile.device_id);
  }

  const { data: topRows } = await supabase
    .from('scores')
    .select('id, device_id, username, avatar_seed, score, stage_reached, created_at')
    .order('score', { ascending: false })
    .limit(10);

  const top10 = (topRows ?? []) as unknown as ScoreRow[];
  const isTop10 = top10.some((r) => r.device_id === profile.device_id);

  let rank: number | null = null;
  if (!isTop10) {
    const { count } = await supabase
      .from('scores')
      .select('id', { count: 'exact', head: true })
      .gt('score', score);
    rank = count != null ? count + 1 : null;
  }

  return { isTop10, rank };
}

export async function fetchLeaderboard(): Promise<{ top: ScoreRow[]; myRank: number | null; myScore: number }> {
  const profile = loadLocalProfile();

  const { data: topRows, error } = await supabase
    .from('scores')
    .select('id, device_id, username, avatar_seed, score, stage_reached, created_at')
    .order('score', { ascending: false })
    .limit(10);

  if (error) {
    return { top: [], myRank: null, myScore: profile?.best_score ?? 0 };
  }

  const top = (topRows ?? []) as unknown as ScoreRow[];

  let myRank: number | null = null;
  const myScore = profile?.best_score ?? 0;

  if (profile && myScore > 0) {
    const inTop = top.some((r) => r.device_id === profile.device_id);
    if (inTop) {
      myRank = top.findIndex((r) => r.device_id === profile.device_id) + 1;
    } else {
      const { count } = await supabase
        .from('scores')
        .select('id', { count: 'exact', head: true })
        .gt('score', myScore);
      myRank = count != null ? count + 1 : null;
    }
  }

  return { top, myRank, myScore };
}
