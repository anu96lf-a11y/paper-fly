import { Platform } from 'react-native';

type SoundName = 'flap' | 'pass' | 'crash' | 'transition' | 'click';

class SoundManager {
  private enabled = true;
  private audioCtx: AudioContext | null = null;

  setEnabled(v: boolean) {
    this.enabled = v;
    const storage = this.getStorage();
    if (storage) storage.setItem('paperfly_sound', v ? 'on' : 'off');
  }

  isEnabled() {
    return this.enabled;
  }

  initFromStorage() {
    const storage = this.getStorage();
    if (storage) {
      const v = storage.getItem('paperfly_sound');
      if (v === 'off') this.enabled = false;
      else this.enabled = true;
    }
  }

  private getStorage(): Storage | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) return window.localStorage;
    } catch {
      // ignore
    }
    return null;
  }

  private ctx(): AudioContext | null {
    if (Platform.OS !== 'web') return null;
    if (!this.enabled) return null;
    if (!this.audioCtx) {
      try {
        const AC = (window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext }).AudioContext
          ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (AC) this.audioCtx = new AC();
      } catch {
        return null;
      }
    }
    return this.audioCtx;
  }

  private tone(freq: number, duration: number, type: OscillatorType, volume: number, slideTo?: number) {
    const ctx = this.ctx();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    if (slideTo) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(slideTo, 1), ctx.currentTime + duration);
    }
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  }

  play(name: SoundName) {
    if (!this.enabled) return;
    switch (name) {
      case 'flap':
        this.tone(520, 0.12, 'sine', 0.18, 740);
        break;
      case 'pass':
        this.tone(880, 0.14, 'triangle', 0.22, 1180);
        setTimeout(() => this.tone(1180, 0.1, 'triangle', 0.18), 80);
        break;
      case 'crash':
        this.tone(180, 0.35, 'sawtooth', 0.28, 60);
        setTimeout(() => this.tone(90, 0.3, 'square', 0.2, 40), 60);
        break;
      case 'transition':
        this.tone(440, 0.5, 'sine', 0.18, 880);
        setTimeout(() => this.tone(660, 0.5, 'sine', 0.16, 990), 150);
        setTimeout(() => this.tone(880, 0.5, 'sine', 0.14, 1320), 300);
        break;
      case 'click':
        this.tone(660, 0.06, 'square', 0.14, 880);
        break;
    }
  }
}

export const sound = new SoundManager();
