export type StageId = 1 | 2 | 3 | 4;

export interface Obstacle {
  id: number;
  x: number;
  gapY: number;
  gapSize: number;
  passed: boolean;
  variant: 'pipe' | 'building' | 'drum' | 'cloud';
  rotating?: boolean;
  rotation: number;
}

export interface GameState {
  status: 'idle' | 'intro' | 'playing' | 'crashed' | 'revive-prompt' | 'gameover';
  planeY: number;
  planeVY: number;
  planeRotation: number;
  obstacles: Obstacle[];
  score: number;
  bestScore: number;
  stage: StageId;
  stageTime: number;
  speed: number;
  reviveAvailable: boolean;
  gameoverCount: number;
}

export interface ScoreRow {
  id: string;
  device_id: string;
  username: string;
  avatar_seed: string | null;
  score: number;
  stage_reached: number;
  created_at: string;
}

export interface PlayerProfile {
  device_id: string;
  username: string;
  avatar_seed: string;
  best_score: number;
}
