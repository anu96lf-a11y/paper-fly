import { Platform } from 'react-native';

// AdMob test ad unit IDs (Google's official test IDs).
// Replace with real ad unit IDs before publishing.
export const ADMOB = {
  banner: Platform.OS === 'ios'
    ? 'ca-app-pub-3940256099942544/2934735716'
    : 'ca-app-pub-3940256099942544/6300978111',
  interstitial: Platform.OS === 'ios'
    ? 'ca-app-pub-3940256099942544/4411468910'
    : 'ca-app-pub-3940256099942544/1033173712',
  rewarded: Platform.OS === 'ios'
    ? 'ca-app-pub-3940256099942544/1712485313'
    : 'ca-app-pub-3940256099942544/5224354917',
};

export type AdEvent = 'loaded' | 'closed' | 'rewarded' | 'failed' | 'skipped';

type AdCallback = (event: AdEvent) => void;

interface AdModule {
  showBanner(): boolean;
  hideBanner(): void;
  isBannerVisible(): boolean;
  loadInterstitial(): Promise<void>;
  showInterstitial(cb?: AdCallback): Promise<boolean>;
  loadRewarded(): Promise<void>;
  showRewarded(cb?: AdCallback): Promise<boolean>;
}

/**
 * AdMob integration layer.
 *
 * On native (iOS/Android) this would bridge to react-native-google-mobile-ads.
 * That package requires a native build (development build via Expo Dev Client)
 * and cannot run in the in-browser preview, so we detect the platform and use
 * a deterministic simulated ad flow on web. The real native integration points
 * are documented inline so swapping in the native module is straightforward.
 */
class WebAdSimulator implements AdModule {
  private bannerVisible = false;
  private interstitialReady = false;
  private rewardedReady = false;

  showBanner(): boolean {
    this.bannerVisible = true;
    return true;
  }
  hideBanner() {
    this.bannerVisible = false;
  }
  isBannerVisible() {
    return this.bannerVisible;
  }

  async loadInterstitial(): Promise<void> {
    await this.delay(300);
    this.interstitialReady = true;
  }

  async showInterstitial(cb?: AdCallback): Promise<boolean> {
    if (!this.interstitialReady) {
      cb?.('failed');
      return false;
    }
    this.interstitialReady = false;
    cb?.('loaded');
    await this.delay(1800);
    cb?.('closed');
    return true;
  }

  async loadRewarded(): Promise<void> {
    await this.delay(300);
    this.rewardedReady = true;
  }

  async showRewarded(cb?: AdCallback): Promise<boolean> {
    if (!this.rewardedReady) {
      cb?.('failed');
      return false;
    }
    this.rewardedReady = false;
    cb?.('loaded');
    await this.delay(2600);
    cb?.('rewarded');
    cb?.('closed');
    return true;
  }

  private delay(ms: number) {
    return new Promise<void>((r) => setTimeout(r, ms));
  }
}

// Native integration (requires react-native-google-mobile-ads + dev build):
//
//   import mobileAds from 'react-native-google-mobile-ads';
//   await mobileAds().initialize();
//   const interstitial = mobileAds().interstitial(ADMOB.interstitial);
//   const rewarded = mobileAds().rewards(ADMOB.rewarded);
//
// See https://docs.page/invertase/react-native-google-mobile-ads

let _impl: AdModule | null = null;

function getImpl(): AdModule {
  if (_impl) return _impl;
  // Web preview fallback — simulates ad lifecycle deterministically.
  _impl = new WebAdSimulator();
  return _impl;
}

export const ads: AdModule = {
  showBanner: () => getImpl().showBanner(),
  hideBanner: () => getImpl().hideBanner(),
  isBannerVisible: () => getImpl().isBannerVisible(),
  loadInterstitial: () => getImpl().loadInterstitial(),
  showInterstitial: (cb) => getImpl().showInterstitial(cb),
  loadRewarded: () => getImpl().loadRewarded(),
  showRewarded: (cb) => getImpl().showRewarded(cb),
};
