import type { StageId } from './types';

export const SCREEN = {
  width: 400,
  height: 700,
};

export const PHYSICS = {
  gravity: 950,
  flapVelocity: -320,
  maxFallSpeed: 520,
  planeX: 110,
  planeSize: 48,
  rotationUp: -22,
  rotationDown: 55,
  rotationLerp: 0.18,
};

export const OBSTACLES = {
  spacing: 300,
  spacingMin: 240,
  startOffset: 320,
  gapSizeBase: 230,
  gapSizeMin: 150,
  width: 72,
  speedBase: 115,
  speedMax: 300,
  speedRamp: 3.2,
  gapShrinkRate: 1.1,
  spacingShrinkRate: 0.7,
};

export const STAGES = {
  durationSec: 180,
  order: [1, 2, 3, 4] as StageId[],
};

export interface StageTheme {
  id: StageId;
  name: string;
  skyTop: string;
  skyBottom: string;
  groundColor: string;
  obstacleColor: string;
  obstacleAccent: string;
  accent: string;
  particle: string;
}

export const STAGE_THEMES: Record<StageId, StageTheme> = {
  1: {
    id: 1,
    name: 'Nature & Village',
    skyTop: '#7EC8E3',
    skyBottom: '#C6F0C6',
    groundColor: '#4A9B4A',
    obstacleColor: '#7BAE3F',
    obstacleAccent: '#5E8B2D',
    accent: '#FFD56B',
    particle: '#FFFFFF',
  },
  2: {
    id: 2,
    name: 'City & Skyscrapers',
    skyTop: '#4A6FA5',
    skyBottom: '#A8C5E8',
    groundColor: '#3D3D4F',
    obstacleColor: '#5A5A72',
    obstacleAccent: '#7A7A95',
    accent: '#FFB347',
    particle: '#E8E8F0',
  },
  3: {
    id: 3,
    name: 'Industrial Zone',
    skyTop: '#6B5B4F',
    skyBottom: '#B8A595',
    groundColor: '#3A2F28',
    obstacleColor: '#8B5A2B',
    obstacleAccent: '#B07840',
    accent: '#FF6B35',
    particle: '#D4C5A9',
  },
  4: {
    id: 4,
    name: 'Sky & Clouds',
    skyTop: '#1B1F3B',
    skyBottom: '#5B3A6E',
    groundColor: '#2E2750',
    obstacleColor: '#7A6BA8',
    obstacleAccent: '#A89BCD',
    accent: '#FFE66D',
    particle: '#E8E0FF',
  },
};
