/**
 * Paper Fly Service Worker — offline-first caching for PWA play.
 *
 * Caches the app shell (HTML, JS, CSS, icons) on install so the game
 * loads and plays without a network connection after the first visit.
 * Scores are submitted to Supabase when back online; the game itself
 * runs fully client-side and needs no network to play.
 */

const CACHE_NAME = 'paperfly-v1';
const OFFLINE_URL = '/index.html';

// App shell assets to pre-cache. The main JS bundle hash changes on
// each build, so we cache it dynamically on first fetch instead.
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
  '/icon-192.png',
  '/icon-512.png',
  '/icon-maskable-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // Use individual fetches so a missing icon doesn't break install
      return Promise.allSettled(
        PRECACHE_URLS.map((url) => cache.add(url).catch(() => undefined)),
      );
    }),
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)),
      ),
    ),
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Only handle GET requests
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Never cache Supabase API calls — they need live network
  if (url.hostname.includes('supabase.co')) {
    return;
  }

  // Same-origin: cache-first (app shell, JS bundles, icons)
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) {
          // Update cache in background (stale-while-revalidate)
          fetch(request)
            .then((res) => {
              if (res && res.status === 200) {
                const clone = res.clone();
                caches.open(CACHE_NAME).then((c) => c.put(request, clone));
              }
            })
            .catch(() => undefined);
          return cached;
        }
        // Not cached — fetch, cache, and return
        return fetch(request)
          .then((res) => {
            if (!res || res.status !== 200 || res.type === 'opaque') return res;
            const clone = res.clone();
            caches.open(CACHE_NAME).then((c) => c.put(request, clone));
            return res;
          })
          .catch(() => caches.match(OFFLINE_URL));
      }),
    );
    return;
  }

  // Cross-origin: try network, fall back to cache
  event.respondWith(
    fetch(request).catch(() => caches.match(request)),
  );
});
